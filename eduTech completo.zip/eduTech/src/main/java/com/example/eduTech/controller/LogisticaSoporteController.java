package com.example.eduTech.controller;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/logistica-soporte")
@Tag(name = "Logística y Soporte", description = "Operaciones relacionadas con logística y soporte")
public class LogisticaSoporteController {

    @Autowired
    private LogisticaSoporteRepository logisticaSoporteRepository;

    @GetMapping
    @Operation(summary = "Obtener todos los registros de logística y soporte")
    public List<LogisticaSoporte> getAll() {
        return logisticaSoporteRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Crear un registro de logística y soporte")
    @ApiResponse(responseCode = "201", description = "Registro creado exitosamente")
    public LogisticaSoporte create(@Valid @RequestBody LogisticaSoporte logisticaSoporte) {
        return logisticaSoporteRepository.save(logisticaSoporte);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un registro de logística y soporte por ID")
    public LogisticaSoporte getById(@Parameter(description = "ID del registro") @PathVariable Integer id) {
        return logisticaSoporteRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Registro de logística y soporte no encontrado con ID: " + id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un registro de logística y soporte")
    public LogisticaSoporte update(@Parameter(description = "ID del registro") @PathVariable Integer id,
                                   @Valid @RequestBody LogisticaSoporte logisticaSoporteDetails) {
        return logisticaSoporteRepository.findById(id).map(logisticaSoporte -> {
            logisticaSoporte.setNombre(logisticaSoporteDetails.getNombre());
            logisticaSoporte.setCorreo(logisticaSoporteDetails.getCorreo());
            logisticaSoporte.setTelefono(logisticaSoporteDetails.getTelefono());
            logisticaSoporte.setUsuario(logisticaSoporteDetails.getUsuario());
            logisticaSoporte.setContrasena(logisticaSoporteDetails.getContrasena());
            return logisticaSoporteRepository.save(logisticaSoporte);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Registro de logística y soporte no encontrado con ID: " + id));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar un registro de logística y soporte")
    @ApiResponse(responseCode = "204", description = "Registro eliminado exitosamente")
    public void delete(@Parameter(description = "ID del registro") @PathVariable Integer id) {
        if (!logisticaSoporteRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Registro de logística y soporte no encontrado con ID: " + id);
        }
        logisticaSoporteRepository.deleteById(id);
    }
}