package com.example.eduTech.controller;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.repository.AdministradorRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/administradores")
@Tag(name = "Administradores", description = "Operaciones relacionadas con administradores")
public class AdminitradorController {

    @Autowired
    private AdministradorRepository administradorRepository;

    @GetMapping
    @Operation(summary = "Obtener todos los administradores")
    public List<Administrador> getAll() {
        return administradorRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // <-- CAMBIO CLAVE AQUÍ
    @Operation(summary = "Crear un administrador")
    @ApiResponse(responseCode = "201", description = "Administrador creado exitosamente")
    public Administrador create(@Valid @RequestBody Administrador administrador) {
        // Podrías añadir lógica de servicio aquí para validar duplicados
        return administradorRepository.save(administrador);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un administrador por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Administrador encontrado"),
        @ApiResponse(responseCode = "404", description = "Administrador no encontrado")
    })
    public Administrador getById(@Parameter(description = "ID del administrador") @PathVariable Integer id) {
        return administradorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con ID: " + id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un administrador")
    public Administrador update(@Parameter(description = "ID del administrador") @PathVariable Integer id,
                              @Valid @RequestBody Administrador administradorDetails) {
        return administradorRepository.findById(id).map(administrador -> {
            administrador.setNombre(administradorDetails.getNombre());
            administrador.setCorreo(administradorDetails.getCorreo());
            administrador.setTelefono(administradorDetails.getTelefono());
            administrador.setUsuario(administradorDetails.getUsuario());
            administrador.setContrasena(administradorDetails.getContrasena());
            return administradorRepository.save(administrador);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con ID: " + id));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Es buena práctica devolver 204 en un DELETE exitoso
    @Operation(summary = "Eliminar un administrador")
    @ApiResponse(responseCode = "204", description = "Administrador eliminado exitosamente")
    public void delete(@Parameter(description = "ID del administrador") @PathVariable Integer id) {
        if (!administradorRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Administrador no encontrado con ID: " + id);
        }
        administradorRepository.deleteById(id);
    }
}