package com.example.eduTech.services;

import com.example.eduTech.dto.RentaProfesorDTO;
import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.repository.RentaProfesorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RentaProfesorService {

    @Autowired
    private RentaProfesorRepository rentaProfesorRepository;

    // Métodos que devuelven DTOs
    @Transactional(readOnly = true)
    public List<RentaProfesorDTO> getAllDTOs() {
        return rentaProfesorRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Optional<RentaProfesorDTO> getDTOById(Integer id) {
        return rentaProfesorRepository.findById(id)
                .map(this::convertToDTO);
    }

    // Conversor de entidad a DTO
    private RentaProfesorDTO convertToDTO(RentaProfesor renta) {
        RentaProfesorDTO dto = new RentaProfesorDTO();
        dto.setId_renta(renta.getId_renta());
        dto.setEstado(renta.getEstado());
        dto.setTotal(renta.getTotal());

        // Cliente
        if (renta.getCliente() != null) {
            RentaProfesorDTO.ClienteDTO clienteDTO = new RentaProfesorDTO.ClienteDTO();
            clienteDTO.setId_cliente(renta.getCliente().getId_cliente());
            clienteDTO.setNombre(renta.getCliente().getNombre());
            clienteDTO.setCorreo(renta.getCliente().getCorreo());
            dto.setCliente(clienteDTO);
        }

        // Instructor
        if (renta.getInstructor() != null) {
            RentaProfesorDTO.InstructorDTO instructorDTO = new RentaProfesorDTO.InstructorDTO();
            instructorDTO.setId_instructor(renta.getInstructor().getId_instructor());
            instructorDTO.setNombre(renta.getInstructor().getNombre());
            dto.setInstructor(instructorDTO);
        }

        // Cursos
        if (renta.getCursos() != null) {
            List<RentaProfesorDTO.CursoDTO> cursoDTOs = renta.getCursos().stream().map(curso -> {
                RentaProfesorDTO.CursoDTO cursoDTO = new RentaProfesorDTO.CursoDTO();
                cursoDTO.setId_curso(curso.getId_curso());
                cursoDTO.setNombre(curso.getNombre());
                cursoDTO.setDuracion(curso.getDuracion());
                return cursoDTO;
            }).collect(Collectors.toList());
            dto.setCursos(cursoDTOs);
        }

        return dto;
    }

    // Métodos CRUD con la entidad
    @Transactional(readOnly = true)
    public List<RentaProfesor> getAll() {
        return rentaProfesorRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<RentaProfesor> getById(Integer id) {
        return rentaProfesorRepository.findById(id);
    }

    public RentaProfesor create(RentaProfesor renta) {
        return rentaProfesorRepository.save(renta);
    }

    public Optional<RentaProfesor> update(Integer id, RentaProfesor rentaDetails) {
        return rentaProfesorRepository.findById(id).map(renta -> {
            renta.setEstado(rentaDetails.getEstado());
            renta.setTotal(rentaDetails.getTotal());
            renta.setCliente(rentaDetails.getCliente());
            renta.setInstructor(rentaDetails.getInstructor());
            renta.setCursos(rentaDetails.getCursos());
            return rentaProfesorRepository.save(renta);
        });
    }

    public void delete(Integer id) {
        rentaProfesorRepository.deleteById(id);
    }
}