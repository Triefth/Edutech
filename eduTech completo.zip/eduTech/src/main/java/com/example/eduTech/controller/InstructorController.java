package com.example.eduTech.controller;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/instructores")
@Tag(name = "Instructores", description = "Operaciones relacionadas con instructores")
public class InstructorController {

    @Autowired
    private InstructorRepository instructorRepository;

    @GetMapping
    @Operation(summary = "Obtener todos los instructores")
    public List<Instructor> getAll() {
        return instructorRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Devuelve 201 en lugar de 200
    @Operation(summary = "Crear un instructor")
    @ApiResponse(responseCode = "201", description = "Instructor creado exitosamente")
    public Instructor create(@Valid @RequestBody Instructor instructor) {
        // Aquí podrías usar un servicio para validar datos duplicados
        return instructorRepository.save(instructor);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un instructor por ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Instructor encontrado"),
        @ApiResponse(responseCode = "404", description = "Instructor no encontrado")
    })
    public Instructor getById(@Parameter(description = "ID del instructor") @PathVariable Integer id) {
        // Lanza un 404 si no se encuentra, en lugar de devolver null
        return instructorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor no encontrado con ID: " + id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un instructor")
    public Instructor update(@Parameter(description = "ID del instructor") @PathVariable Integer id,
                           @Valid @RequestBody Instructor instructorDetails) {
        // Lanza un 404 si el instructor a actualizar no existe
        return instructorRepository.findById(id).map(instructor -> {
            instructor.setNombre(instructorDetails.getNombre());
            instructor.setCorreo(instructorDetails.getCorreo());
            instructor.setTelefono(instructorDetails.getTelefono());
            instructor.setUsuario(instructorDetails.getUsuario());
            instructor.setContrasena(instructorDetails.getContrasena());
            return instructorRepository.save(instructor);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor no encontrado con ID: " + id));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Devuelve 204 en un borrado exitoso
    @Operation(summary = "Eliminar un instructor")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Instructor eliminado exitosamente"),
        @ApiResponse(responseCode = "404", description = "Instructor no encontrado")
    })
    public void delete(@Parameter(description = "ID del instructor") @PathVariable Integer id) {
        // Verifica si existe antes de borrar para poder devolver un 404 si no existe
        if (!instructorRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Instructor no encontrado con ID: " + id);
        }
        instructorRepository.deleteById(id);
    }
}