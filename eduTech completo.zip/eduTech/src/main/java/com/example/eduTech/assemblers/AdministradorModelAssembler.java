package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.AdministradorControllerV2;
import com.example.eduTech.model.Administrador;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class AdministradorModelAssembler implements RepresentationModelAssembler<Administrador, EntityModel<Administrador>> {

    @Override
    public EntityModel<Administrador> toModel(Administrador entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(AdministradorControllerV2.class).getAdministradorById(entity.getId_administrador())).withSelfRel(),
                linkTo(methodOn(AdministradorControllerV2.class).getAll()).withRel("administradores"));
    }
}