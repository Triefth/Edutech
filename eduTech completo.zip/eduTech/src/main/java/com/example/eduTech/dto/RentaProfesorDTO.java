package com.example.eduTech.dto;

import lombok.Data;
import java.util.List;

// Un DTO es una clase simple, sin anotaciones de JPA.
// Solo contiene los campos que queremos exponer en la API.
@Data
public class RentaProfesorDTO {
    private Integer id_renta;
    private ClienteDTO cliente;
    private InstructorDTO instructor;
    private List<CursoDTO> cursos;
    private String estado;
    private Double total;

    // Podríamos añadir DTOs anidados para mostrar solo la información necesaria
    @Data
    public static class ClienteDTO {
        private Integer id_cliente;
        private String nombre;
        private String correo;
    }

    @Data
    public static class InstructorDTO {
        private Integer id_instructor;
        private String nombre;
    }

    @Data
    public static class CursoDTO {
        private Integer id_curso;
        private String nombre;
        private Integer duracion;
    }
}