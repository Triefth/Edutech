package com.example.eduTech.repository;

import com.example.eduTech.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio para la entidad Curso.
 * Proporciona todas las operaciones CRUD (Crear, Leer, Actualizar, Eliminar)
 * de forma automática gracias a la herencia de JpaRepository.
 */
@Repository
public interface CursoRepository extends JpaRepository<Curso, Integer> {
    // No se necesitan métodos personalizados en este momento.
    // Spring Data JPA ya proporciona métodos como:
    // - save(Curso curso)
    // - findById(Integer id)
    // - findAll()
    // - deleteById(Integer id)
    // - etc.
}