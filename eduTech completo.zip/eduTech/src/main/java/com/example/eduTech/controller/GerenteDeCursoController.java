package com.example.eduTech.controller;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/gerentes-de-cursos")
@Tag(name = "Gerentes de Cursos", description = "Operaciones relacionadas con gerentes de cursos")
public class GerenteDeCursoController {

    @Autowired
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    @GetMapping
    @Operation(summary = "Obtener todos los gerentes de cursos")
    public List<GerenteDeCursos> getAll() {
        return gerenteDeCursoRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // <-- Soluciona el error 201 vs 200
    @Operation(summary = "Crear un gerente de curso")
    public GerenteDeCursos create(@Valid @RequestBody GerenteDeCursos gerente) {
        // Aquí podrías usar GerenteDeCursosService para validar duplicados
        return gerenteDeCursoRepository.save(gerente);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un gerente de curso por ID")
    public GerenteDeCursos getById(@Parameter(description = "ID del gerente") @PathVariable Integer id) {
        // --- Soluciona el error 404 vs 200 ---
        return gerenteDeCursoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Gerente de curso no encontrado con ID: " + id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un gerente de curso")
    public GerenteDeCursos update(@Parameter(description = "ID del gerente") @PathVariable Integer id,
                                  @Valid @RequestBody GerenteDeCursos gerenteDetails) {
        // --- Soluciona el error de no encontrar para actualizar ---
        return gerenteDeCursoRepository.findById(id).map(gerente -> {
            gerente.setNombre(gerenteDetails.getNombre());
            gerente.setCorreo(gerenteDetails.getCorreo());
            gerente.setTelefono(gerenteDetails.getTelefono());
            gerente.setUsuario(gerenteDetails.getUsuario());
            gerente.setContrasena(gerenteDetails.getContrasena());
            return gerenteDeCursoRepository.save(gerente);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Gerente de curso no encontrado con ID: " + id));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // <-- Soluciona el error 204 vs 200
    @Operation(summary = "Eliminar un gerente de curso")
    public void delete(@Parameter(description = "ID del gerente") @PathVariable Integer id) {
        if (!gerenteDeCursoRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Gerente de curso no encontrado con ID: " + id);
        }
        gerenteDeCursoRepository.deleteById(id);
    }
}