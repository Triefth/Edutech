package com.example.eduTech.services;

import com.example.eduTech.model.Curso;
import com.example.eduTech.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public List<Curso> getAll() {
        return cursoRepository.findAll();
    }

    public Optional<Curso> getById(Integer id) {
        return cursoRepository.findById(id);
    }

    public Curso create(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Optional<Curso> update(Integer id, Curso cursoDetails) {
        return cursoRepository.findById(id).map(curso -> {
            curso.setNombre(cursoDetails.getNombre());
            curso.setDescripcion(cursoDetails.getDescripcion());
            curso.setDuracion(cursoDetails.getDuracion());
            return cursoRepository.save(curso);
        });
    }

    public void delete(Integer id) {
        cursoRepository.deleteById(id);
    }
}