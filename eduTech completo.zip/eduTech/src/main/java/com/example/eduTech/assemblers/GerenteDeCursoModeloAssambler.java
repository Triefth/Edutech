package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.GerenteDeCursoControllerV2;
import com.example.eduTech.model.GerenteDeCursos;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class GerenteDeCursoModeloAssambler implements RepresentationModelAssembler<GerenteDeCursos, EntityModel<GerenteDeCursos>> {

    @Override
    public EntityModel<GerenteDeCursos> toModel(GerenteDeCursos entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(GerenteDeCursoControllerV2.class).getGerenteDeCursoById(entity.getId_gerente())).withSelfRel(),
                linkTo(methodOn(GerenteDeCursoControllerV2.class).getAll()).withRel("gerentesDeCurso"));
    }
}