package com.example.eduTech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "gerentes_de_cursos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GerenteDeCursos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_gerente;

    @NotBlank(message = "El nombre no puede estar vacío.")
    @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres.")
    private String nombre;

    @NotBlank(message = "El correo no puede estar vacío.")
    @Email(message = "El formato del correo electrónico no es válido.")
    @Size(max = 100, message = "El correo no puede tener más de 100 caracteres.")
    private String correo;

    @NotBlank(message = "El teléfono no puede estar vacío.")
    @Size(max = 20, message = "El teléfono no puede tener más de 20 caracteres.")
    private String telefono;

    @NotBlank(message = "El nombre de usuario no puede estar vacío.")
    @Size(min = 4, max = 50, message = "El nombre de usuario debe tener entre 4 y 50 caracteres.")
    private String usuario;

    @NotBlank(message = "La contraseña no puede estar vacía.")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres.")
    private String contrasena;
}