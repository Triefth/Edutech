package com.example.eduTech.controller;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.repository.ClienteRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/clientes")
@Tag(name = "Clientes", description = "Operaciones relacionadas con clientes")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los clientes",
        description = "Obtiene una lista de todos los clientes disponibles en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = Cliente.class)),
                examples = @ExampleObject(
                    name = "EjemploListaClientes",
                    value = "[{\"id_cliente\":1,\"nombre\":\"Carlos\",\"telefono\":\"123456789\",\"correo\":\"carlos@mail.com\",\"direccion\":\"Calle 123\"}]"
                )
            )
        )
    })
    public List<Cliente> getAll() {
        return clienteRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un cliente",
        description = "Crea un nuevo cliente en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Cliente creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Cliente.class),
                examples = @ExampleObject(
                    name = "EjemploCliente",
                    value = "{\"id_cliente\":2,\"nombre\":\"Ana\",\"telefono\":\"987654321\",\"correo\":\"ana@mail.com\",\"direccion\":\"Avenida 456\"}"
                )
            )
        )
    })
    public Cliente create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Cliente a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = Cliente.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Ana\",\"telefono\":\"987654321\",\"correo\":\"ana@mail.com\",\"direccion\":\"Avenida 456\"}"
                )
            )
        )
        @Valid @RequestBody Cliente cliente // <-- aquí se agrega @Valid
    ) {
        return clienteRepository.save(cliente);
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un cliente por ID",
        description = "Obtiene un cliente específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Cliente encontrado",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Cliente no encontrado\"}"
                )
            )
        )
    })
    public Cliente getById(
        @Parameter(description = "ID del cliente", required = true)
        @PathVariable Integer id
    ) {
        return clienteRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un cliente",
        description = "Actualiza los datos de un cliente existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Cliente actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Cliente.class),
                examples = @ExampleObject(
                    name = "EjemploClienteActualizado",
                    value = "{\"id_cliente\":1,\"nombre\":\"Carlos Actualizado\",\"telefono\":\"123456789\",\"correo\":\"carlos@mail.com\",\"direccion\":\"Calle 123\"}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Cliente no encontrado\"}"
                )
            )
        )
    })
    public Cliente update(
        @Parameter(description = "ID del cliente", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody Cliente clienteDetails // <-- aquí se agrega @Valid
    ) {
        return clienteRepository.findById(id).map(cliente -> {
            cliente.setNombre(clienteDetails.getNombre());
            cliente.setTelefono(clienteDetails.getTelefono());
            cliente.setCorreo(clienteDetails.getCorreo());
            cliente.setDireccion(clienteDetails.getDireccion());
            return clienteRepository.save(cliente);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un cliente",
        description = "Elimina un cliente por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Cliente eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Cliente no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del cliente", required = true)
        @PathVariable Integer id
    ) {
        clienteRepository.deleteById(id);
    }
}