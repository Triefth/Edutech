package com.example.eduTech.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Table(name = "rentas_profesor")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RentaProfesor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_renta;

    @NotNull(message = "La renta debe estar asociada a un cliente.")
    @ManyToOne(fetch = FetchType.LAZY) // <-- CAMBIO AQUÍ
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @NotNull(message = "La renta debe estar asociada a un instructor.")
    @ManyToOne(fetch = FetchType.LAZY) // <-- CAMBIO AQUÍ
    @JoinColumn(name = "id_instructor", nullable = false)
    private Instructor instructor;

    @NotEmpty(message = "La renta debe contener al menos un curso.")
    @ManyToMany(fetch = FetchType.LAZY) // <-- CAMBIO AQUÍ
    @JoinTable(
        name = "renta_profesor_cursos",
        joinColumns = @JoinColumn(name = "id_renta"),
        inverseJoinColumns = @JoinColumn(name = "id_curso")
    )
    private List<Curso> cursos;

    @NotBlank(message = "El estado de la renta no puede estar vacío.")
    private String estado;

    @NotNull(message = "El total no puede ser nulo.")
    @Min(value = 0, message = "El total no puede ser un valor negativo.")
    private Double total;
}