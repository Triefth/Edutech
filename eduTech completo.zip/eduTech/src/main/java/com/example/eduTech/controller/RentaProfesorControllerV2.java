package com.example.eduTech.controller;

import com.example.eduTech.dto.RentaProfesorDTO; // <-- Importante: Importar el DTO
import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.services.RentaProfesorService;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v2/rentas-profesor")
@Tag(name = "Rentas Profesor V2", description = "Operaciones para rentas de profesores (persistentes)")
public class RentaProfesorControllerV2 {

    @Autowired
    private RentaProfesorService rentaProfesorService;

    // Se ha quitado el Assembler temporalmente para asegurar la funcionalidad con DTOs.

    @GetMapping
    @Operation(summary = "Obtener todas las rentas de profesor")
    public ResponseEntity<List<RentaProfesorDTO>> getAll() {
        List<RentaProfesorDTO> rentasDTO = rentaProfesorService.getAllDTOs();
        return ResponseEntity.ok(rentasDTO);
    }

    @GetMapping(value = "/{id}")
    @Operation(summary = "Obtener una renta de profesor por ID")
    public ResponseEntity<RentaProfesorDTO> getRentaProfesorById(@PathVariable Integer id) {
        RentaProfesorDTO rentaDTO = rentaProfesorService.getDTOById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Renta de profesor no encontrada con ID: " + id));
        return ResponseEntity.ok(rentaDTO);
    }

    @PostMapping
    @Operation(summary = "Crear una renta de profesor")
    public ResponseEntity<RentaProfesor> createRentaProfesor(@Valid @RequestBody RentaProfesor renta) {
        // El servicio recibe la entidad completa para crearla
        RentaProfesor nuevaRenta = rentaProfesorService.create(renta);
        // Devolvemos la entidad persistida para confirmar
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaRenta);
    }

    @PutMapping(value = "/{id}")
    @Operation(summary = "Actualizar una renta de profesor")
    public ResponseEntity<RentaProfesor> updateRentaProfesor(@PathVariable Integer id, @Valid @RequestBody RentaProfesor rentaDetails) {
        RentaProfesor actualizado = rentaProfesorService.update(id, rentaDetails)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Renta no encontrada con ID: " + id));
        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar una renta de profesor")
    public ResponseEntity<?> deleteRentaProfesor(@PathVariable Integer id) {
        // Verificamos si existe antes de borrar para lanzar nuestro 404 personalizado
        rentaProfesorService.getDTOById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Renta no encontrada con ID: " + id));
        rentaProfesorService.delete(id);
        return ResponseEntity.noContent().build();
    }
}