package com.example.eduTech.repository;

import com.example.eduTech.model.RentaProfesor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RentaProfesorRepository extends JpaRepository<RentaProfesor, Integer> {
}