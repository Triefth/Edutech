package com.example.eduTech.repository;

import com.example.eduTech.model.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface AdministradorRepository extends JpaRepository<Administrador, Integer> {

    /**
     * Busca un administrador por su dirección de correo electrónico.
     * Spring Data JPA genera automáticamente la consulta.
     * @param correo El correo a buscar.
     * @return un Optional que contiene al administrador si se encuentra, o vacío si no.
     */
    Optional<Administrador> findByCorreo(String correo);

    /**
     * Busca un administrador por su nombre de usuario.
     * Spring Data JPA genera automáticamente la consulta.
     * @param usuario El nombre de usuario a buscar.
     * @return un Optional que contiene al administrador si se encuentra, o vacío si no.
     */
    Optional<Administrador> findByUsuario(String usuario);
}