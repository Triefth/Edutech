package com.example.eduTech.controller;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.services.InstructorService; // Usamos el Servicio
import com.example.eduTech.assemblers.InstructorModeloAssambler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Importamos Valid
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/instructores")
@Tag(name = "Instructores V2", description = "Operaciones HATEOAS para instructores")
public class InstructorControllerV2 {

    @Autowired
    private InstructorService instructorService; // Inyectamos el Servicio

    @Autowired
    private InstructorModeloAssambler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los instructores")
    public CollectionModel<EntityModel<Instructor>> getAll() {
        List<EntityModel<Instructor>> instructores = instructorService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(instructores, linkTo(methodOn(InstructorControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un instructor por ID")
    public EntityModel<Instructor> getInstructorById(@PathVariable Integer id) {
        Instructor instructor = instructorService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor no encontrado con ID: " + id));
        return assembler.toModel(instructor);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un instructor")
    public ResponseEntity<EntityModel<Instructor>> createInstructor(@Valid @RequestBody Instructor instructor) {
        Instructor nuevoInstructor = instructorService.create(instructor);
        EntityModel<Instructor> entityModel = assembler.toModel(nuevoInstructor);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un instructor")
    public ResponseEntity<EntityModel<Instructor>> updateInstructor(@PathVariable Integer id, @Valid @RequestBody Instructor instructorDetails) {
        Instructor actualizado = instructorService.update(id, instructorDetails)
            .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Instructor no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un instructor")
    public ResponseEntity<?> deleteInstructor(@PathVariable Integer id) {
        instructorService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Instructor no encontrado con ID: " + id));
        instructorService.delete(id);
        return ResponseEntity.noContent().build();
    }
}