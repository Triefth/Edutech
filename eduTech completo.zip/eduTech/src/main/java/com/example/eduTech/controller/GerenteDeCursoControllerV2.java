package com.example.eduTech.controller;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.services.GerenteDeCursosService; // Usamos el Servicio
import com.example.eduTech.assemblers.GerenteDeCursoModeloAssambler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Importamos Valid
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/gerentes-curso")
@Tag(name = "Gerentes de Curso V2", description = "Operaciones HATEOAS para gerentes de curso")
public class GerenteDeCursoControllerV2 {

    @Autowired
    private GerenteDeCursosService gerenteDeCursoService; // Inyectamos el Servicio

    @Autowired
    private GerenteDeCursoModeloAssambler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los gerentes de curso")
    public CollectionModel<EntityModel<GerenteDeCursos>> getAll() {
        List<EntityModel<GerenteDeCursos>> gerentes = gerenteDeCursoService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(gerentes, linkTo(methodOn(GerenteDeCursoControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un gerente de curso por ID")
    public EntityModel<GerenteDeCursos> getGerenteDeCursoById(@PathVariable Integer id) {
        GerenteDeCursos gerente = gerenteDeCursoService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Gerente de curso no encontrado con ID: " + id));
        return assembler.toModel(gerente);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un gerente de curso")
    public ResponseEntity<EntityModel<GerenteDeCursos>> createGerenteDeCurso(@Valid @RequestBody GerenteDeCursos gerente) {
        GerenteDeCursos nuevoGerente = gerenteDeCursoService.create(gerente);
        EntityModel<GerenteDeCursos> entityModel = assembler.toModel(nuevoGerente);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un gerente de curso")
    public ResponseEntity<EntityModel<GerenteDeCursos>> updateGerenteDeCurso(@PathVariable Integer id, @Valid @RequestBody GerenteDeCursos gerenteDetails) {
        GerenteDeCursos actualizado = gerenteDeCursoService.update(id, gerenteDetails)
            .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Gerente de curso no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un gerente de curso")
    public ResponseEntity<?> deleteGerenteDeCurso(@PathVariable Integer id) {
        gerenteDeCursoService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Gerente de curso no encontrado con ID: " + id));
        gerenteDeCursoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}