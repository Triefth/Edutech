package com.example.eduTech.controller;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.services.ClienteService; // Usamos el Servicio
import com.example.eduTech.assemblers.ClienteModeloAssambler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Importamos Valid
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/clientes")
@Tag(name = "Clientes V2", description = "Operaciones HATEOAS para clientes")
public class ClienteControllerV2 {

    @Autowired
    private ClienteService clienteService; // Inyectamos el Servicio

    @Autowired
    private ClienteModeloAssambler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los clientes")
    public CollectionModel<EntityModel<Cliente>> getAll() {
        List<EntityModel<Cliente>> clientes = clienteService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(clientes, linkTo(methodOn(ClienteControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un cliente por ID")
    public EntityModel<Cliente> getClienteById(@PathVariable Integer id) {
        Cliente cliente = clienteService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con ID: " + id));
        return assembler.toModel(cliente);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un cliente")
    public ResponseEntity<EntityModel<Cliente>> createCliente(@Valid @RequestBody Cliente cliente) {
        Cliente nuevoCliente = clienteService.create(cliente);
        EntityModel<Cliente> entityModel = assembler.toModel(nuevoCliente);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un cliente")
    public ResponseEntity<EntityModel<Cliente>> updateCliente(@PathVariable Integer id, @Valid @RequestBody Cliente clienteDetails) {
        Cliente actualizado = clienteService.update(id, clienteDetails)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Cliente no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un cliente")
    public ResponseEntity<?> deleteCliente(@PathVariable Integer id) {
        clienteService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Cliente no encontrado con ID: " + id));
        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }
}