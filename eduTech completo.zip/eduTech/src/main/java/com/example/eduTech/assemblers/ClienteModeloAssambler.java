package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.ClienteControllerV2;
import com.example.eduTech.model.Cliente;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class ClienteModeloAssambler implements RepresentationModelAssembler<Cliente, EntityModel<Cliente>> {

    @Override
    public EntityModel<Cliente> toModel(Cliente entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(ClienteControllerV2.class).getClienteById(entity.getId_cliente())).withSelfRel(),
                linkTo(methodOn(ClienteControllerV2.class).getAll()).withRel("clientes"));
    }
}