package com.example.eduTech.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;
import com.example.eduTech.exception.GlobalExceptionHandler;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(GerenteDeCursoController.class)
@Import(GlobalExceptionHandler.class) // Importamos el manejador de excepciones
public class GerenteDeCursoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private GerenteDeCursos gerenteValido;

    @BeforeEach
    void setUp() {
        gerenteValido = new GerenteDeCursos();
        gerenteValido.setId_gerente(1);
        gerenteValido.setNombre("Laura Valida");
        gerenteValido.setCorreo("laura@valido.com");
        gerenteValido.setTelefono("123456789");
        gerenteValido.setUsuario("laura123");
        // Contraseña que cumple la regla de @Size(min=6)
        gerenteValido.setContrasena("passwordValida");
    }

    @Test
    public void testGetAllGerentes() throws Exception {
        when(gerenteDeCursoRepository.findAll()).thenReturn(List.of(gerenteValido));

        mockMvc.perform(get("/gerentes-de-cursos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].nombre").value("Laura Valida"));
    }

    @Test
    public void testGetGerenteByIdFound() throws Exception {
        when(gerenteDeCursoRepository.findById(1)).thenReturn(Optional.of(gerenteValido));

        mockMvc.perform(get("/gerentes-de-cursos/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Laura Valida"));
    }

    @Test
    public void testGetGerenteByIdNotFound() throws Exception {
        when(gerenteDeCursoRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/gerentes-de-cursos/2"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testCreateGerente_WithValidData_ShouldReturnCreated() throws Exception {
        when(gerenteDeCursoRepository.save(any(GerenteDeCursos.class))).thenReturn(gerenteValido);

        mockMvc.perform(post("/gerentes-de-cursos")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(gerenteValido)))
            .andExpect(status().isCreated()) // Esperamos 201 Created
            .andExpect(jsonPath("$.nombre").value("Laura Valida"));
    }

    @Test
    public void testCreateGerente_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        GerenteDeCursos gerenteInvalido = new GerenteDeCursos();
        gerenteInvalido.setNombre("L"); // Inválido por @Size(min=3)
        gerenteInvalido.setCorreo("correo-invalido"); // Inválido por @Email
        gerenteInvalido.setContrasena("123"); // Inválido por @Size(min=6)

        mockMvc.perform(post("/gerentes-de-cursos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(gerenteInvalido)))
            .andExpect(status().isBadRequest());
    }

    @Test
    public void testUpdateGerenteFound() throws Exception {
        GerenteDeCursos updated = new GerenteDeCursos();
        updated.setId_gerente(1);
        updated.setNombre("Laura Actualizada");
        updated.setCorreo("laura.actualizada@valido.com");
        updated.setTelefono("987654321");
        updated.setUsuario("lauraUPD");
        updated.setContrasena("nuevaPasswordValida"); // Contraseña válida

        when(gerenteDeCursoRepository.findById(1)).thenReturn(Optional.of(gerenteValido));
        when(gerenteDeCursoRepository.save(any(GerenteDeCursos.class))).thenReturn(updated);

        mockMvc.perform(put("/gerentes-de-cursos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Laura Actualizada"));
    }
    
    @Test
    public void testDeleteGerente() throws Exception {
        when(gerenteDeCursoRepository.existsById(1)).thenReturn(true);
        doNothing().when(gerenteDeCursoRepository).deleteById(1);

        mockMvc.perform(delete("/gerentes-de-cursos/1"))
            .andExpect(status().isNoContent()); // Esperamos 204 No Content
    }
}