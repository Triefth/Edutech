package com.example.eduTech.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;
import com.example.eduTech.exception.GlobalExceptionHandler;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(LogisticaSoporteController.class)
@Import(GlobalExceptionHandler.class)
public class LogisticaSoporteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LogisticaSoporteRepository logisticaSoporteRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private LogisticaSoporte logisticaValida;

    @BeforeEach
    void setUp() {
        logisticaValida = new LogisticaSoporte();
        logisticaValida.setId_logistica_soporte(1);
        logisticaValida.setNombre("Juan Valido");
        logisticaValida.setCorreo("juan@valido.com");
        logisticaValida.setTelefono("123456789");
        logisticaValida.setUsuario("juan123");
        // Contraseña que cumple la regla de @Size(min=6)
        logisticaValida.setContrasena("passwordValida");
    }

    @Test
    public void testGetAllLogisticaSoporte() throws Exception {
        when(logisticaSoporteRepository.findAll()).thenReturn(List.of(logisticaValida));

        mockMvc.perform(get("/logistica-soporte"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].nombre").value("Juan Valido"));
    }

    @Test
    public void testGetLogisticaSoporteByIdFound() throws Exception {
        when(logisticaSoporteRepository.findById(1)).thenReturn(Optional.of(logisticaValida));

        mockMvc.perform(get("/logistica-soporte/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Juan Valido"));
    }

    @Test
    public void testGetLogisticaSoporteByIdNotFound() throws Exception {
        when(logisticaSoporteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/logistica-soporte/2"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testCreateLogisticaSoporte_WithValidData_ShouldReturnCreated() throws Exception {
        when(logisticaSoporteRepository.save(any(LogisticaSoporte.class))).thenReturn(logisticaValida);

        mockMvc.perform(post("/logistica-soporte")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(logisticaValida)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.nombre").value("Juan Valido"));
    }
    
    @Test
    public void testCreateLogisticaSoporte_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        LogisticaSoporte logisticaInvalida = new LogisticaSoporte();
        logisticaInvalida.setNombre("J"); // Inválido
        logisticaInvalida.setCorreo("email-invalido"); // Inválido
        logisticaInvalida.setContrasena("123"); // Inválido

        mockMvc.perform(post("/logistica-soporte")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(logisticaInvalida)))
            .andExpect(status().isBadRequest());
    }

    @Test
    public void testUpdateLogisticaSoporteFound() throws Exception {
        LogisticaSoporte updated = new LogisticaSoporte();
        updated.setNombre("Juan Actualizado");
        updated.setCorreo("juan.actualizado@valido.com");
        updated.setTelefono("987654321");
        updated.setUsuario("juanUPD");
        updated.setContrasena("nuevaPasswordValida"); // Contraseña válida

        when(logisticaSoporteRepository.findById(1)).thenReturn(Optional.of(logisticaValida));
        when(logisticaSoporteRepository.save(any(LogisticaSoporte.class))).thenReturn(updated);

        mockMvc.perform(put("/logistica-soporte/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Juan Actualizado"));
    }

    @Test
    public void testDeleteLogisticaSoporte() throws Exception {
        when(logisticaSoporteRepository.existsById(1)).thenReturn(true);
        doNothing().when(logisticaSoporteRepository).deleteById(1);

        mockMvc.perform(delete("/logistica-soporte/1"))
            .andExpect(status().isNoContent());
    }
}