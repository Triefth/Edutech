package com.example.eduTech.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;
import com.example.eduTech.exception.GlobalExceptionHandler;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(InstructorController.class)
@Import(GlobalExceptionHandler.class) // Importamos el manejador de excepciones
public class InstructorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InstructorRepository instructorRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Instructor instructorValido;

    @BeforeEach
    void setUp() {
        instructorValido = new Instructor();
        instructorValido.setId_instructor(1);
        instructorValido.setNombre("Luis Valido");
        instructorValido.setCorreo("luis@valido.com");
        instructorValido.setTelefono("123456789");
        instructorValido.setUsuario("luis123");
        // Contraseña que cumple la regla de @Size(min=6)
        instructorValido.setContrasena("passwordValida");
    }

    @Test
    public void testGetAllInstructores() throws Exception {
        when(instructorRepository.findAll()).thenReturn(List.of(instructorValido));

        mockMvc.perform(get("/instructores"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].nombre").value("Luis Valido"));
    }

    @Test
    public void testGetInstructorByIdFound() throws Exception {
        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructorValido));

        mockMvc.perform(get("/instructores/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Luis Valido"));
    }

    @Test
    public void testGetInstructorByIdNotFound() throws Exception {
        when(instructorRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/instructores/2"))
            .andExpect(status().isNotFound());
    }

    @Test
    public void testCreateInstructor_WithValidData_ShouldReturnCreated() throws Exception {
        when(instructorRepository.save(any(Instructor.class))).thenReturn(instructorValido);

        mockMvc.perform(post("/instructores")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(instructorValido)))
            .andExpect(status().isCreated()) // Esperamos 201 Created
            .andExpect(jsonPath("$.nombre").value("Luis Valido"));
    }
    
    @Test
    public void testCreateInstructor_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        Instructor instructorInvalido = new Instructor();
        instructorInvalido.setNombre("L"); // Inválido por @Size
        instructorInvalido.setCorreo("correo-invalido"); // Inválido por @Email

        mockMvc.perform(post("/instructores")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(instructorInvalido)))
            .andExpect(status().isBadRequest());
    }

    @Test
    public void testUpdateInstructorFound() throws Exception {
        Instructor updated = new Instructor();
        updated.setId_instructor(1);
        updated.setNombre("Luis Actualizado");
        updated.setCorreo("luis.actualizado@valido.com");
        updated.setTelefono("987654321");
        updated.setUsuario("luisUPD");
        updated.setContrasena("nuevaPasswordValida"); // Contraseña válida

        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructorValido));
        when(instructorRepository.save(any(Instructor.class))).thenReturn(updated);

        mockMvc.perform(put("/instructores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Luis Actualizado"));
    }
    
    @Test
    public void testDeleteInstructor() throws Exception {
        when(instructorRepository.existsById(1)).thenReturn(true);
        doNothing().when(instructorRepository).deleteById(1);

        mockMvc.perform(delete("/instructores/1"))
            .andExpect(status().isNoContent()); // Esperamos 204 No Content
    }
}