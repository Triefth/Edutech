package com.example.eduTech.controller;

import com.example.eduTech.exception.GlobalExceptionHandler;
import com.example.eduTech.model.Cliente;
import com.example.eduTech.model.Curso;
import com.example.eduTech.model.Instructor;
import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.services.RentaProfesorCarritoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RentaProfesorController.class)
@Import(GlobalExceptionHandler.class) // Importante para que las pruebas de @Valid funcionen
public class RentaProfesorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RentaProfesorCarritoService rentaProfesorCarritoService;

    @Autowired
    private ObjectMapper objectMapper;

    private RentaProfesor rentaValida;

    @BeforeEach
    void setUp() {
        // --- CREAMOS UN OBJETO VÁLIDO ---
        Cliente cliente = new Cliente(1, "Test Client", "123", "test@c.com", "dir", null);
        Instructor instructor = new Instructor(1, "Test Instructor", "123", "test@i.com", "user", "passValida", null);
        Curso curso = new Curso(1, "Test Course", "desc", 10, null);
        
        rentaValida = new RentaProfesor(1, cliente, instructor, Collections.singletonList(curso), "en_carrito", 150.0);
    }

    @Test
    void testAgregarAlCarrito_WithValidData_ShouldReturnCreated() throws Exception {
        // Arrange
        // No necesitamos mockear el servicio, ya que la validación ocurre antes.
        // Pero lo hacemos para que la llamada no falle si se llega a ella.
        when(rentaProfesorCarritoService.agregarRenta(any(RentaProfesor.class))).thenReturn("Renta agregada");

        // Act & Assert
        mockMvc.perform(post("/api/v1/renta-profesor")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rentaValida)))
            .andExpect(status().isCreated());
    }
    
    @Test
    void testAgregarAlCarrito_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        // Arrange: Creamos un objeto inválido (cliente es null)
        RentaProfesor rentaInvalida = new RentaProfesor(null, null, null, null, "", null);

        // Act & Assert
        mockMvc.perform(post("/api/v1/renta-profesor")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(rentaInvalida)))
            .andExpect(status().isBadRequest());
    }

    @Test
    void testVerCarrito() throws Exception {
        when(rentaProfesorCarritoService.verCarrito()).thenReturn(List.of(rentaValida));

        mockMvc.perform(get("/api/v1/renta-profesor"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$[0].estado").value("en_carrito"));
    }

    @Test
    void testEliminarDelCarrito() throws Exception {
        when(rentaProfesorCarritoService.eliminarRenta(0)).thenReturn("Renta eliminada");
        
        mockMvc.perform(delete("/api/v1/renta-profesor/eliminar/0"))
            .andExpect(status().isNoContent());
    }
}