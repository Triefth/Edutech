package com.example.eduTech.services;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LogisticaSoporteServiceTest {

    @Mock
    private LogisticaSoporteRepository logisticaSoporteRepository;

    @InjectMocks
    private LogisticaSoporteService logisticaSoporteService;

    private LogisticaSoporte logistica;

    @BeforeEach
    void setUp() {
        logistica = new LogisticaSoporte(1, "Marta", "marta@mail.com", "333222111", "marta123", "pass");
    }

    @Test
    void testGetAll_ShouldReturnListOfLogistica() {
        when(logisticaSoporteRepository.findAll()).thenReturn(Collections.singletonList(logistica));
        List<LogisticaSoporte> lista = logisticaSoporteService.getAll();
        assertNotNull(lista);
        assertEquals(1, lista.size());
        verify(logisticaSoporteRepository, times(1)).findAll();
    }
    
    @Test
    void testCreate_WhenEmailAlreadyExists_ShouldThrowException() {
        // Arrange
        LogisticaSoporte nuevaLogistica = new LogisticaSoporte(null, "Otro Nombre", "marta@mail.com", "111", "otroUser", "pass");
        when(logisticaSoporteRepository.findByCorreo("marta@mail.com")).thenReturn(Optional.of(logistica));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            logisticaSoporteService.create(nuevaLogistica);
        });

        assertEquals("El correo electrónico 'marta@mail.com' ya está en uso.", exception.getMessage());
        verify(logisticaSoporteRepository, never()).save(any(LogisticaSoporte.class));
    }

    @Test
    void testCreate_WhenUsuarioAlreadyExists_ShouldThrowException() {
        // Arrange
        LogisticaSoporte nuevaLogistica = new LogisticaSoporte(null, "Otro Nombre", "otro@mail.com", "111", "marta123", "pass");
        when(logisticaSoporteRepository.findByUsuario("marta123")).thenReturn(Optional.of(logistica));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            logisticaSoporteService.create(nuevaLogistica);
        });

        assertEquals("El nombre de usuario 'marta123' ya está en uso.", exception.getMessage());
        verify(logisticaSoporteRepository, never()).save(any(LogisticaSoporte.class));
    }
}