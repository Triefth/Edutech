package com.example.eduTech.controller;
import com.example.eduTech.model.Administrador;

import com.example.eduTech.repository.AdministradorRepository;
import com.example.eduTech.services.AdministradorService; 
import com.example.eduTech.exception.GlobalExceptionHandler; 

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import org.springframework.http.HttpStatus; 
import org.springframework.web.bind.annotation.ResponseStatus; 

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.databind.ObjectMapper;

// Apuntamos al controlador V1
@WebMvcTest(AdminitradorController.class)
// Importamos nuestro manejador de excepciones para que se use en las pruebas
@Import(GlobalExceptionHandler.class)
public class AdministradorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    // Aunque el controlador V1 usa el repositorio directamente, 
    // es buena práctica empezar a mockear el servicio.
    // Si tu AdminitradorController usa el Repositorio, deja este MockBean.
    @MockBean
    private AdministradorRepository administradorRepository;
    
    // Si refactorizaste el V1 para usar el Servicio, usa este en su lugar:
    // @MockBean
    // private AdministradorService administradorService;

    @Autowired
    private ObjectMapper objectMapper;

    private Administrador adminValido;

    @BeforeEach
    void setUp() {
        // --- CAMBIO CLAVE: USAR DATOS VÁLIDOS ---
        adminValido = new Administrador();
        adminValido.setId_administrador(1);
        adminValido.setNombre("Pedro Valido");
        adminValido.setCorreo("pedro@valido.com");
        adminValido.setTelefono("123456789");
        adminValido.setUsuario("pedro123");
        // La contraseña ahora cumple la regla @Size(min=6)
        adminValido.setContrasena("passwordValida"); 
    }

    @Test
    public void testGetAllAdministradores() throws Exception {
        when(administradorRepository.findAll()).thenReturn(List.of(adminValido));

        mockMvc.perform(get("/administradores"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].nombre").value("Pedro Valido"));
    }
    
    // ... las pruebas de GET se quedan igual ...

    @Test
    public void testCreateAdministrador_WithValidData_ShouldReturnCreated() throws Exception {
        // Asumimos que el controlador V1 devuelve 201 Created ahora
        when(administradorRepository.save(any(Administrador.class))).thenReturn(adminValido);

        mockMvc.perform(post("/administradores")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(adminValido)))
            .andExpect(status().isCreated()) // <-- CAMBIO: Es más correcto esperar 201 para un POST exitoso
            .andExpect(jsonPath("$.nombre").value("Pedro Valido"));
    }

    // --- NUEVA PRUEBA PARA VALIDACIÓN ---
    @Test
    public void testCreateAdministrador_WithInvalidData_ShouldReturnBadRequest() throws Exception {
        // Creamos un admin con una contraseña demasiado corta
        Administrador adminInvalido = new Administrador();
        adminInvalido.setNombre("Pedro Invalido");
        adminInvalido.setCorreo("pedro@invalido.com");
        adminInvalido.setTelefono("123");
        adminInvalido.setUsuario("ped");
        adminInvalido.setContrasena("123"); // Viola la regla de min=6

        mockMvc.perform(post("/administradores")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(adminInvalido)))
            .andExpect(status().isBadRequest());
    }
    
    // ... las demás pruebas de update y delete deben usar `adminValido` ...
     @Test
    public void testUpdateAdministradorFound() throws Exception {
        Administrador updated = new Administrador();
        updated.setId_administrador(1);
        updated.setNombre("Pedro Actualizado");
        updated.setCorreo("pedro@valido.com");
        updated.setTelefono("123456789");
        updated.setUsuario("pedro123");
        updated.setContrasena("passwordValida"); // Usa una contraseña válida

        when(administradorRepository.findById(1)).thenReturn(Optional.of(adminValido));
        when(administradorRepository.save(any(Administrador.class))).thenReturn(updated);

        mockMvc.perform(put("/administradores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Pedro Actualizado"));
    }

}