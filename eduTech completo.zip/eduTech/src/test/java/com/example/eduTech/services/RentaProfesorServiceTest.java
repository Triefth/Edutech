package com.example.eduTech.services;

import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.repository.RentaProfesorRepository;
import com.example.eduTech.dto.RentaProfesorDTO; // Importar DTO
import com.example.eduTech.model.Cliente;
import com.example.eduTech.model.Instructor;
import com.example.eduTech.model.Curso;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RentaProfesorServiceTest {

    @Mock
    private RentaProfesorRepository rentaProfesorRepository;

    @InjectMocks
    private RentaProfesorService rentaProfesorService;

    private RentaProfesor renta;

    @BeforeEach
    void setUp() {
        // Creamos objetos completos para la prueba del DTO
        Cliente cliente = new Cliente(1, "Test Client", "123", "test@c.com", "dir", null);
        Instructor instructor = new Instructor(1, "Test Instructor", "123", "test@i.com", "user", "pass", null);
        Curso curso = new Curso(1, "Test Course", "desc", 10, null);
        
        renta = new RentaProfesor(1, cliente, instructor, Collections.singletonList(curso), "confirmada", 250.0);
    }
    
    @Test
    void testGetDTOById_WhenRentaExists_ShouldReturnDTO() {
        // Arrange
        when(rentaProfesorRepository.findById(1)).thenReturn(Optional.of(renta));

        // Act
        Optional<RentaProfesorDTO> resultadoDTO = rentaProfesorService.getDTOById(1);

        // Assert
        assertTrue(resultadoDTO.isPresent());
        assertEquals(1, resultadoDTO.get().getId_renta());
        assertEquals("Test Client", resultadoDTO.get().getCliente().getNombre());
        assertEquals("Test Instructor", resultadoDTO.get().getInstructor().getNombre());
        assertEquals(1, resultadoDTO.get().getCursos().size());
        assertEquals("Test Course", resultadoDTO.get().getCursos().get(0).getNombre());
        
        verify(rentaProfesorRepository, times(1)).findById(1);
    }
    
    @Test
    void testCreate_ShouldReturnSavedRenta() {
        // Arrange
        when(rentaProfesorRepository.save(any(RentaProfesor.class))).thenReturn(renta);

        // Act
        RentaProfesor rentaGuardada = rentaProfesorService.create(new RentaProfesor());

        // Assert
        assertNotNull(rentaGuardada);
        assertEquals(1, rentaGuardada.getId_renta());
        verify(rentaProfesorRepository, times(1)).save(any(RentaProfesor.class));
    }
}