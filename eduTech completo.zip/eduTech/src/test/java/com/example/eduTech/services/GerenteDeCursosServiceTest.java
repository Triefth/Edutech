package com.example.eduTech.services;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GerenteDeCursosServiceTest {

    @Mock
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    @InjectMocks
    private GerenteDeCursosService gerenteDeCursosService;

    private GerenteDeCursos gerente;

    @BeforeEach
    void setUp() {
        gerente = new GerenteDeCursos(1, "Laura", "laura@mail.com", "123456789", "laura123", "pass");
    }

    @Test
    void testGetAll_ShouldReturnListOfGerentes() {
        when(gerenteDeCursoRepository.findAll()).thenReturn(Collections.singletonList(gerente));
        List<GerenteDeCursos> gerentes = gerenteDeCursosService.getAll();
        assertNotNull(gerentes);
        assertEquals(1, gerentes.size());
        verify(gerenteDeCursoRepository, times(1)).findAll();
    }
    
    @Test
    void testCreate_WhenEmailAlreadyExists_ShouldThrowException() {
        // Arrange
        GerenteDeCursos nuevoGerente = new GerenteDeCursos(null, "Otro Nombre", "laura@mail.com", "111", "otroUser", "pass");
        when(gerenteDeCursoRepository.findByCorreo("laura@mail.com")).thenReturn(Optional.of(gerente));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            gerenteDeCursosService.create(nuevoGerente);
        });

        assertEquals("El correo electrónico 'laura@mail.com' ya está en uso.", exception.getMessage());
        verify(gerenteDeCursoRepository, never()).save(any(GerenteDeCursos.class));
    }

    @Test
    void testCreate_WhenUsuarioAlreadyExists_ShouldThrowException() {
        // Arrange
        GerenteDeCursos nuevoGerente = new GerenteDeCursos(null, "Otro Nombre", "otro@mail.com", "111", "laura123", "pass");
        when(gerenteDeCursoRepository.findByUsuario("laura123")).thenReturn(Optional.of(gerente));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            gerenteDeCursosService.create(nuevoGerente);
        });

        assertEquals("El nombre de usuario 'laura123' ya está en uso.", exception.getMessage());
        verify(gerenteDeCursoRepository, never()).save(any(GerenteDeCursos.class));
    }
}