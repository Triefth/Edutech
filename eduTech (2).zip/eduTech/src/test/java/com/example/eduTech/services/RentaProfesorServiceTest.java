package com.example.eduTech.services;

import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.repository.RentaProfesorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RentaProfesorServiceTest {

    @Mock
    private RentaProfesorRepository rentaProfesorRepository;

    @InjectMocks
    private RentaProfesorService rentaProfesorService;

    private RentaProfesor renta;

    @BeforeEach
    void setUp() {
        renta = new RentaProfesor();
        renta.setId_renta(1);
        renta.setEstado("confirmada");
        renta.setTotal(250.0);
        // No es necesario poblar las relaciones para la mayoría de los tests de servicio
    }

    @Test
    void testGetAll_ShouldReturnListOfRentas() {
        // Arrange
        when(rentaProfesorRepository.findAll()).thenReturn(Collections.singletonList(renta));

        // Act
        List<RentaProfesor> rentas = rentaProfesorService.getAll();

        // Assert
        assertNotNull(rentas);
        assertEquals(1, rentas.size());
        assertEquals("confirmada", rentas.get(0).getEstado());
        verify(rentaProfesorRepository, times(1)).findAll();
    }

    @Test
    void testGetById_WhenRentaExists_ShouldReturnRenta() {
        // Arrange
        when(rentaProfesorRepository.findById(1)).thenReturn(Optional.of(renta));

        // Act
        Optional<RentaProfesor> resultado = rentaProfesorService.getById(1);

        // Assert
        assertTrue(resultado.isPresent());
        assertEquals(renta.getEstado(), resultado.get().getEstado());
        verify(rentaProfesorRepository, times(1)).findById(1);
    }

    @Test
    void testGetById_WhenRentaDoesNotExist_ShouldReturnEmpty() {
        // Arrange
        when(rentaProfesorRepository.findById(99)).thenReturn(Optional.empty());

        // Act
        Optional<RentaProfesor> resultado = rentaProfesorService.getById(99);

        // Assert
        assertFalse(resultado.isPresent());
        verify(rentaProfesorRepository, times(1)).findById(99);
    }

    @Test
    void testCreate_ShouldReturnSavedRenta() {
        // Arrange
        when(rentaProfesorRepository.save(any(RentaProfesor.class))).thenReturn(renta);

        // Act
        RentaProfesor nuevaRenta = new RentaProfesor(); // Renta sin ID
        nuevaRenta.setEstado("confirmada");
        RentaProfesor rentaGuardada = rentaProfesorService.create(nuevaRenta);

        // Assert
        assertNotNull(rentaGuardada);
        assertEquals(1, rentaGuardada.getId_renta());
        verify(rentaProfesorRepository, times(1)).save(any(RentaProfesor.class));
    }

    @Test
    void testDelete_ShouldCallDeleteById() {
        // Arrange
        int rentaId = 1;
        doNothing().when(rentaProfesorRepository).deleteById(rentaId);

        // Act
        rentaProfesorService.delete(rentaId);

        // Assert
        verify(rentaProfesorRepository, times(1)).deleteById(rentaId);
    }
}