package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(InstructorController.class)
public class InstructorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private InstructorRepository instructorRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Instructor instructor;

    @BeforeEach
    void setUp() {
        instructor = new Instructor();
        instructor.setId_instructor(1);
        instructor.setNombre("Luis");
        instructor.setCorreo("luis@mail.com");
        instructor.setTelefono("123456789");
        instructor.setUsuario("luis123");
        instructor.setContrasena("pass");
    }

    @Test
    public void testGetAllInstructores() throws Exception {
        when(instructorRepository.findAll()).thenReturn(List.of(instructor));

        mockMvc.perform(get("/instructores"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_instructor").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Luis"));
    }

    @Test
    public void testGetInstructorByIdFound() throws Exception {
        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructor));

        mockMvc.perform(get("/instructores/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Luis"));
    }

    @Test
    public void testGetInstructorByIdNotFound() throws Exception {
        when(instructorRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/instructores/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateInstructor() throws Exception {
        when(instructorRepository.save(any(Instructor.class))).thenReturn(instructor);

        mockMvc.perform(post("/instructores")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(instructor)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Luis"));
    }

    @Test
    public void testUpdateInstructorFound() throws Exception {
        Instructor updated = new Instructor();
        updated.setId_instructor(1);
        updated.setNombre("Luis Actualizado");
        updated.setCorreo("luis@mail.com");
        updated.setTelefono("123456789");
        updated.setUsuario("luis123");
        updated.setContrasena("pass");

        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructor));
        when(instructorRepository.save(any(Instructor.class))).thenReturn(updated);

        mockMvc.perform(put("/instructores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Luis Actualizado"));
    }

    @Test
    public void testUpdateInstructorNotFound() throws Exception {
        when(instructorRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/instructores/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(instructor)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteInstructor() throws Exception {
        doNothing().when(instructorRepository).deleteById(1);

        mockMvc.perform(delete("/instructores/1"))
            .andExpect(status().isOk());
    }
}