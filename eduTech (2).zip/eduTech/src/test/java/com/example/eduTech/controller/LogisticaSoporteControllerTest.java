package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(LogisticaSoporteController.class)
public class LogisticaSoporteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LogisticaSoporteRepository logisticaSoporteRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private LogisticaSoporte logisticaSoporte;

    @BeforeEach
    void setUp() {
        logisticaSoporte = new LogisticaSoporte();
        logisticaSoporte.setId_logistica_soporte(1);
        logisticaSoporte.setNombre("Juan");
        logisticaSoporte.setCorreo("juan@mail.com");
        logisticaSoporte.setTelefono("123456789");
        logisticaSoporte.setUsuario("juan123");
        logisticaSoporte.setContrasena("pass");
    }

    @Test
    public void testGetAllLogisticaSoporte() throws Exception {
        when(logisticaSoporteRepository.findAll()).thenReturn(List.of(logisticaSoporte));

        mockMvc.perform(get("/logistica-soporte"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_logistica_soporte").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Juan"));
    }

    @Test
    public void testGetLogisticaSoporteByIdFound() throws Exception {
        when(logisticaSoporteRepository.findById(1)).thenReturn(Optional.of(logisticaSoporte));

        mockMvc.perform(get("/logistica-soporte/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Juan"));
    }

    @Test
    public void testGetLogisticaSoporteByIdNotFound() throws Exception {
        when(logisticaSoporteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/logistica-soporte/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateLogisticaSoporte() throws Exception {
        when(logisticaSoporteRepository.save(any(LogisticaSoporte.class))).thenReturn(logisticaSoporte);

        mockMvc.perform(post("/logistica-soporte")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(logisticaSoporte)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Juan"));
    }

    @Test
    public void testUpdateLogisticaSoporteFound() throws Exception {
        LogisticaSoporte updated = new LogisticaSoporte();
        updated.setId_logistica_soporte(1);
        updated.setNombre("Juan Actualizado");
        updated.setCorreo("juan@mail.com");
        updated.setTelefono("123456789");
        updated.setUsuario("juan123");
        updated.setContrasena("pass");

        when(logisticaSoporteRepository.findById(1)).thenReturn(Optional.of(logisticaSoporte));
        when(logisticaSoporteRepository.save(any(LogisticaSoporte.class))).thenReturn(updated);

        mockMvc.perform(put("/logistica-soporte/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Juan Actualizado"));
    }

    @Test
    public void testUpdateLogisticaSoporteNotFound() throws Exception {
        when(logisticaSoporteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/logistica-soporte/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(logisticaSoporte)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteLogisticaSoporte() throws Exception {
        doNothing().when(logisticaSoporteRepository).deleteById(1);

        mockMvc.perform(delete("/logistica-soporte/1"))
            .andExpect(status().isOk());
    }
}