package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import com.example.eduTech.model.Curso;
import com.example.eduTech.model.Instructor;
import com.example.eduTech.model.Cliente;
import com.example.eduTech.repository.CursoRepository;
import com.example.eduTech.repository.InstructorRepository;
import com.example.eduTech.repository.ClienteRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

@WebMvcTest(RentaProfesorController.class)
public class RentaProfesorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CursoRepository cursoRepository;

    @MockBean
    private InstructorRepository instructorRepository;

    @MockBean
    private ClienteRepository clienteRepository;

    private Curso curso;
    private Instructor instructor;
    private Cliente cliente;

    @BeforeEach
void setUp() {
    curso = new Curso();
    curso.setId_curso(1);
    curso.setNombre("Matemáticas");

    instructor = new Instructor();
    instructor.setId_instructor(1);
    instructor.setNombre("Luis");

    cliente = new Cliente();
    cliente.setId_cliente(1);
    cliente.setNombre("Carlos");
}

    @Test
    public void testAgregarRentaExitoso() throws Exception {
        when(cursoRepository.findById(1)).thenReturn(Optional.of(curso));
        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructor));
        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));

        mockMvc.perform(post("/api/v1/renta-profesor/agregar/1/1/1"))
            .andExpect(status().isOk())
            .andExpect(content().string("Curso agregado al carrito de renta de profesor"));
    }

    @Test
    public void testAgregarRentaNoEncontrado() throws Exception {
        when(cursoRepository.findById(2)).thenReturn(Optional.empty());
        when(instructorRepository.findById(2)).thenReturn(Optional.empty());
        when(clienteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/v1/renta-profesor/agregar/2/2/2"))
            .andExpect(status().isOk())
            .andExpect(content().string("No se encontró curso, instructor o cliente"));
    }

    @Test
    public void testVerCarrito() throws Exception {
        // Primero agrega una renta al carrito
        when(cursoRepository.findById(1)).thenReturn(Optional.of(curso));
        when(instructorRepository.findById(1)).thenReturn(Optional.of(instructor));
        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));

        mockMvc.perform(post("/api/v1/renta-profesor/agregar/1/1/1"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/api/v1/renta-profesor"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].instructor.nombre").value("Luis"))
            .andExpect(jsonPath("$[0].cliente.nombre").value("Carlos"));
    }

    @Test
    public void testEliminarRentaNoEncontrada() throws Exception {
        mockMvc.perform(delete("/api/v1/renta-profesor/eliminar/0"))
            .andExpect(status().isOk())
            .andExpect(content().string("No se encontró la renta en el carrito"));
    }

    @Test
    public void testVaciarCarrito() throws Exception {
        mockMvc.perform(delete("/api/v1/renta-profesor/vaciar"))
            .andExpect(status().isOk())
            .andExpect(content().string("El carrito de renta de profesor está vacío"));
    }

    @Test
    public void testComprar() throws Exception {
        mockMvc.perform(post("/api/v1/renta-profesor/comprar"))
            .andExpect(status().isOk())
            .andExpect(content().string("Renta(s) realizada(s) con éxito"));
    }

    @Test
    public void testTotalRentasCarrito() throws Exception {
        mockMvc.perform(get("/api/v1/renta-profesor/total"))
            .andExpect(status().isOk())
            .andExpect(content().string("0"));
    }
}