package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.repository.ClienteRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(ClienteController.class)
public class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClienteRepository clienteRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente();
        cliente.setId_cliente(1);
        cliente.setNombre("Carlos");
        cliente.setTelefono("123456789");
        cliente.setCorreo("carlos@mail.com");
        cliente.setDireccion("Calle 123");
    }

    @Test
    public void testGetAllClientes() throws Exception {
        when(clienteRepository.findAll()).thenReturn(List.of(cliente));

        mockMvc.perform(get("/clientes"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_cliente").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Carlos"));
    }

    @Test
    public void testGetClienteByIdFound() throws Exception {
        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));

        mockMvc.perform(get("/clientes/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Carlos"));
    }

    @Test
    public void testGetClienteByIdNotFound() throws Exception {
        when(clienteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/clientes/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateCliente() throws Exception {
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);

        mockMvc.perform(post("/clientes")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(cliente)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Carlos"));
    }

    @Test
    public void testUpdateClienteFound() throws Exception {
        Cliente updated = new Cliente();
        updated.setId_cliente(1);
        updated.setNombre("Carlos Actualizado");
        updated.setTelefono("123456789");
        updated.setCorreo("carlos@mail.com");
        updated.setDireccion("Calle 123");

        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));
        when(clienteRepository.save(any(Cliente.class))).thenReturn(updated);

        mockMvc.perform(put("/clientes/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Carlos Actualizado"));
    }

    @Test
    public void testUpdateClienteNotFound() throws Exception {
        when(clienteRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/clientes/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(cliente)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteCliente() throws Exception {
        doNothing().when(clienteRepository).deleteById(1);

        mockMvc.perform(delete("/clientes/1"))
            .andExpect(status().isOk());
    }
}