package com.example.eduTech.services;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.model.Curso;
import com.example.eduTech.model.Instructor;
import com.example.eduTech.model.RentaProfesor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Probamos el servicio de Carrito
class RentaProfesorCarritoServiceTest {

    // La variable debe ser del tipo del servicio que estamos probando
    private RentaProfesorCarritoService rentaProfesorCarritoService;

    private RentaProfesor rentaDePrueba;

    @BeforeEach
    void setUp() {
        // Creamos una nueva instancia del servicio de Carrito
        rentaProfesorCarritoService = new RentaProfesorCarritoService();

        // El resto del setup es idéntico
        Cliente cliente = new Cliente(1, "Carlos", "123", "carlos@mail.com", "Calle Falsa 123", null);
        Instructor instructor = new Instructor(1, "Profesor Jirafales", "prof@mail.com", "456", "prof123", "pass", null);
        Curso curso = new Curso(1, "Matemáticas I", "Curso de intro", 40, null);

        rentaDePrueba = new RentaProfesor();
        rentaDePrueba.setId_renta(1);
        rentaDePrueba.setCliente(cliente);
        rentaDePrueba.setInstructor(instructor);
        rentaDePrueba.setCursos(Collections.singletonList(curso));
        rentaDePrueba.setEstado("pendiente");
        rentaDePrueba.setTotal(100.0);
    }

    // A partir de aquí, todas las llamadas usan la variable "rentaProfesorCarritoService"
    @Test
    void testAgregarRenta_ShouldAddRentaToCarrito() {
        String resultadoMsg = rentaProfesorCarritoService.agregarRenta(rentaDePrueba);
        List<RentaProfesor> carrito = rentaProfesorCarritoService.verCarrito();
        assertEquals("Curso agregado al carrito de renta de profesor", resultadoMsg);
        assertEquals(1, carrito.size());
    }

    @Test
    void testVerCarrito_WhenEmpty_ShouldReturnEmptyList() {
        List<RentaProfesor> carrito = rentaProfesorCarritoService.verCarrito();
        assertTrue(carrito.isEmpty());
    }

    @Test
    void testEliminarRenta_WhenRentaExists_ShouldRemoveIt() {
        rentaProfesorCarritoService.agregarRenta(rentaDePrueba);
        String resultadoMsg = rentaProfesorCarritoService.eliminarRenta(0);
        assertEquals("Renta eliminada del carrito", resultadoMsg);
        assertTrue(rentaProfesorCarritoService.verCarrito().isEmpty());
    }

    // ... y así sucesivamente para el resto de los tests, siempre usando "rentaProfesorCarritoService" ...

    @Test
    void testEliminarRenta_WhenIndexIsInvalid_ShouldReturnNotFoundMessage() {
        String resultadoMsg = rentaProfesorCarritoService.eliminarRenta(0);
        assertEquals("No se encontró la renta en el carrito", resultadoMsg);
    }

    @Test
    void testTotalRentasCarrito_ShouldReturnCorrectCount() {
        assertEquals(0, rentaProfesorCarritoService.totalRentasCarrito());
        rentaProfesorCarritoService.agregarRenta(rentaDePrueba);
        assertEquals(1, rentaProfesorCarritoService.totalRentasCarrito());
    }

    @Test
    void testVaciarCarrito_ShouldClearAllRentas() {
        rentaProfesorCarritoService.agregarRenta(rentaDePrueba);
        rentaProfesorCarritoService.vaciarCarrito();
        assertTrue(rentaProfesorCarritoService.verCarrito().isEmpty());
    }
    
    @Test
    void testComprar_ShouldClearCarritoAndReturnSuccessMessage() {
        rentaProfesorCarritoService.agregarRenta(rentaDePrueba);
        String resultadoMsg = rentaProfesorCarritoService.comprar();
        assertEquals("Renta(s) realizada(s) con éxito", resultadoMsg);
        assertTrue(rentaProfesorCarritoService.verCarrito().isEmpty());
    }
}