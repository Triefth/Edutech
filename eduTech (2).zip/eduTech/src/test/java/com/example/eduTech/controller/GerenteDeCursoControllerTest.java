package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(GerenteDeCursoController.class)
public class GerenteDeCursoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private GerenteDeCursos gerente;

    @BeforeEach
    void setUp() {
        gerente = new GerenteDeCursos();
        gerente.setId_gerente(1);
        gerente.setNombre("Laura");
        gerente.setCorreo("laura@mail.com");
        gerente.setTelefono("123456789");
        gerente.setUsuario("laura123");
        gerente.setContrasena("pass");
    }

    @Test
    public void testGetAllGerentes() throws Exception {
        when(gerenteDeCursoRepository.findAll()).thenReturn(List.of(gerente));

        mockMvc.perform(get("/gerentes-de-cursos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_gerente").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Laura"));
    }

    @Test
    public void testGetGerenteByIdFound() throws Exception {
        when(gerenteDeCursoRepository.findById(1)).thenReturn(Optional.of(gerente));

        mockMvc.perform(get("/gerentes-de-cursos/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Laura"));
    }

    @Test
    public void testGetGerenteByIdNotFound() throws Exception {
        when(gerenteDeCursoRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/gerentes-de-cursos/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateGerente() throws Exception {
        when(gerenteDeCursoRepository.save(any(GerenteDeCursos.class))).thenReturn(gerente);

        mockMvc.perform(post("/gerentes-de-cursos")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(gerente)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Laura"));
    }

    @Test
    public void testUpdateGerenteFound() throws Exception {
        GerenteDeCursos updated = new GerenteDeCursos();
        updated.setId_gerente(1);
        updated.setNombre("Laura Actualizada");
        updated.setCorreo("laura@mail.com");
        updated.setTelefono("123456789");
        updated.setUsuario("laura123");
        updated.setContrasena("pass");

        when(gerenteDeCursoRepository.findById(1)).thenReturn(Optional.of(gerente));
        when(gerenteDeCursoRepository.save(any(GerenteDeCursos.class))).thenReturn(updated);

        mockMvc.perform(put("/gerentes-de-cursos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Laura Actualizada"));
    }

    @Test
    public void testUpdateGerenteNotFound() throws Exception {
        when(gerenteDeCursoRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/gerentes-de-cursos/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(gerente)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteGerente() throws Exception {
        doNothing().when(gerenteDeCursoRepository).deleteById(1);

        mockMvc.perform(delete("/gerentes-de-cursos/1"))
            .andExpect(status().isOk());
    }
}