package com.example.eduTech.services;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.repository.AdministradorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdministradorServiceTest {

    @Mock
    private AdministradorRepository administradorRepository;

    @InjectMocks
    private AdministradorService administradorService;

    private Administrador admin;

    @BeforeEach
    void setUp() {
        admin = new Administrador(1, "Pedro", "pedro@mail.com", "123456789", "pedro123", "pass");
    }

    @Test
    void testGetAll_ShouldReturnListOfAdministradores() {
        when(administradorRepository.findAll()).thenReturn(Collections.singletonList(admin));

        List<Administrador> administradores = administradorService.getAll();

        assertNotNull(administradores);
        assertEquals(1, administradores.size());
        assertEquals("Pedro", administradores.get(0).getNombre());
        verify(administradorRepository, times(1)).findAll();
    }

    @Test
    void testGetById_WhenAdministradorExists_ShouldReturnAdministrador() {
        when(administradorRepository.findById(1)).thenReturn(Optional.of(admin));

        Optional<Administrador> resultado = administradorService.getById(1);

        assertTrue(resultado.isPresent());
        assertEquals(admin.getNombre(), resultado.get().getNombre());
        verify(administradorRepository, times(1)).findById(1);
    }

    @Test
    void testGetById_WhenAdministradorDoesNotExist_ShouldReturnEmpty() {
        when(administradorRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Administrador> resultado = administradorService.getById(99);

        assertFalse(resultado.isPresent());
        verify(administradorRepository, times(1)).findById(99);
    }

    @Test
    void testCreate_ShouldReturnSavedAdministrador() {
        when(administradorRepository.save(any(Administrador.class))).thenReturn(admin);

        Administrador nuevoAdmin = new Administrador(null, "Pedro", "pedro@mail.com", "123456789", "pedro123", "pass");
        Administrador adminGuardado = administradorService.create(nuevoAdmin);

        assertNotNull(adminGuardado);
        assertEquals(1, adminGuardado.getId_administrador());
        verify(administradorRepository, times(1)).save(any(Administrador.class));
    }

    @Test
    void testCreate_WhenEmailAlreadyExists_ShouldThrowIllegalArgumentException() {
        // Arrange
        Administrador nuevoAdminConEmailRepetido = new Administrador(null, "Ana", "pedro@mail.com", "987", "ana123", "pass");
        when(administradorRepository.findByCorreo("pedro@mail.com")).thenReturn(Optional.of(admin));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            administradorService.create(nuevoAdminConEmailRepetido);
        });

        assertEquals("El correo electrónico 'pedro@mail.com' ya está en uso.", exception.getMessage());
        verify(administradorRepository, never()).save(any(Administrador.class));
    }

    @Test
    void testCreate_WhenUsuarioAlreadyExists_ShouldThrowIllegalArgumentException() {
        // Arrange
        Administrador nuevoAdminConUsuarioRepetido = new Administrador(null, "Ana", "ana@mail.com", "987", "pedro123", "pass");
        when(administradorRepository.findByUsuario("pedro123")).thenReturn(Optional.of(admin));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            administradorService.create(nuevoAdminConUsuarioRepetido);
        });

        assertEquals("El nombre de usuario 'pedro123' ya está en uso.", exception.getMessage());
        verify(administradorRepository, never()).save(any(Administrador.class));
    }

    @Test
    void testDelete_ShouldCallDeleteById() {
        int adminId = 1;
        doNothing().when(administradorRepository).deleteById(adminId);

        administradorService.delete(adminId);

        verify(administradorRepository, times(1)).deleteById(adminId);
    }
}