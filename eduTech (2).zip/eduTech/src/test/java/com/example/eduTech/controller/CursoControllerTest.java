package com.example.eduTech.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import com.example.eduTech.model.Curso;
import com.example.eduTech.repository.CursoRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(CursoController.class)
public class CursoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CursoRepository cursoRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Curso curso;

    @BeforeEach
    void setUp() {
        curso = new Curso();
        curso.setId_curso(1);
        curso.setNombre("Matemáticas");
        curso.setDescripcion("Curso de matemáticas básicas");
        curso.setDuracion(40);
    }

    @Test
    public void testGetAllCursos() throws Exception {
        when(cursoRepository.findAll()).thenReturn(List.of(curso));

        mockMvc.perform(get("/cursos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_curso").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Matemáticas"));
    }

    @Test
    public void testGetCursoByIdFound() throws Exception {
        when(cursoRepository.findById(1)).thenReturn(Optional.of(curso));

        mockMvc.perform(get("/cursos/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Matemáticas"));
    }

    @Test
    public void testGetCursoByIdNotFound() throws Exception {
        when(cursoRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/cursos/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateCurso() throws Exception {
        when(cursoRepository.save(any(Curso.class))).thenReturn(curso);

        mockMvc.perform(post("/cursos")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(curso)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Matemáticas"));
    }

    @Test
    public void testUpdateCursoFound() throws Exception {
        Curso updated = new Curso();
        updated.setId_curso(1);
        updated.setNombre("Matemáticas Avanzadas");
        updated.setDescripcion("Curso de matemáticas avanzadas");
        updated.setDuracion(60);

        when(cursoRepository.findById(1)).thenReturn(Optional.of(curso));
        when(cursoRepository.save(any(Curso.class))).thenReturn(updated);

        mockMvc.perform(put("/cursos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Matemáticas Avanzadas"));
    }

    @Test
    public void testUpdateCursoNotFound() throws Exception {
        when(cursoRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/cursos/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(curso)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteCurso() throws Exception {
        doNothing().when(cursoRepository).deleteById(1);

        mockMvc.perform(delete("/cursos/1"))
            .andExpect(status().isOk());
    }
}