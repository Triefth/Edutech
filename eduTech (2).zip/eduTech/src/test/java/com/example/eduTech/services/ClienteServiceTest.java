package com.example.eduTech.services;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.repository.ClienteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClienteServiceTest {

    @Mock
    private ClienteRepository clienteRepository;

    @InjectMocks
    private ClienteService clienteService;

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente(Integer.valueOf(1), "Juan Perez", "987654321", "juan.perez@test.com", "Av. Siempre Viva 123", null);
    }

    @Test
    void testGetAll_ShouldReturnListOfClientes() {
        when(clienteRepository.findAll()).thenReturn(Collections.singletonList(cliente));
        List<Cliente> clientes = clienteService.getAll();
        assertNotNull(clientes);
        assertEquals(1, clientes.size());
        assertEquals("Juan Perez", clientes.get(0).getNombre());
        verify(clienteRepository, times(1)).findAll();
    }

    @Test
    void testGetById_WhenClienteExists_ShouldReturnCliente() {
        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));
        Optional<Cliente> resultado = clienteService.getById(1);
        assertTrue(resultado.isPresent());
        assertEquals(cliente.getNombre(), resultado.get().getNombre());
        verify(clienteRepository, times(1)).findById(1);
    }

    @Test
    void testGetById_WhenClienteDoesNotExist_ShouldReturnEmpty() {
        when(clienteRepository.findById(99)).thenReturn(Optional.empty());
        Optional<Cliente> resultado = clienteService.getById(99);
        assertFalse(resultado.isPresent());
        verify(clienteRepository, times(1)).findById(99);
    }

    @Test
    void testCreate_WhenDataIsValid_ShouldReturnSavedCliente() {
        when(clienteRepository.findByCorreo(anyString())).thenReturn(Optional.empty());
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);
        Cliente nuevoCliente = cliente = new Cliente(Integer.valueOf(1), "Juan Perez", "987654321", "juan.perez@test.com", "Av. Siempre Viva 123", null);
        Cliente clienteGuardado = clienteService.create(nuevoCliente);
        assertNotNull(clienteGuardado);
        assertEquals(1, clienteGuardado.getId_cliente());
        verify(clienteRepository, times(1)).save(any(Cliente.class));
    }

    @Test
    void testCreate_WhenEmailAlreadyExists_ShouldThrowException() {
        Cliente nuevoClienteConEmailRepetido = cliente = new Cliente(Integer.valueOf(1), "Juan Perez", "987654321", "juan.perez@test.com", "Av. Siempre Viva 123", null);
        when(clienteRepository.findByCorreo("juan.perez@test.com")).thenReturn(Optional.of(cliente));
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.create(nuevoClienteConEmailRepetido);
        });
        assertEquals("El correo electrónico 'juan.perez@test.com' ya está en uso.", exception.getMessage());
        verify(clienteRepository, never()).save(any(Cliente.class));
    }

    @Test
    void testUpdate_WhenClienteExists_ShouldReturnUpdatedCliente() {
        Cliente detallesActualizados = new Cliente(Integer.valueOf(1), "Juan Perez", "987654321", "juan.perez@test.com", "Av. Siempre Viva 123", null);
        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));
        when(clienteRepository.save(any(Cliente.class))).thenReturn(detallesActualizados);
        Optional<Cliente> resultado = clienteService.update(1, detallesActualizados);
        assertTrue(resultado.isPresent());
        assertEquals("Juan Perez Actualizado", resultado.get().getNombre());
        verify(clienteRepository, times(1)).save(any(Cliente.class));
    }

    @Test
    void testUpdate_WhenClienteDoesNotExist_ShouldReturnEmpty() {
        Cliente detallesActualizados = new Cliente();
        when(clienteRepository.findById(99)).thenReturn(Optional.empty());
        Optional<Cliente> resultado = clienteService.update(99, detallesActualizados);
        assertFalse(resultado.isPresent());
        verify(clienteRepository, never()).save(any(Cliente.class));
    }

    @Test
    void testDelete_ShouldCallDeleteById() {
        int clienteId = 1;
        doNothing().when(clienteRepository).deleteById(clienteId);
        clienteService.delete(clienteId);
        verify(clienteRepository, times(1)).deleteById(clienteId);
    }
}