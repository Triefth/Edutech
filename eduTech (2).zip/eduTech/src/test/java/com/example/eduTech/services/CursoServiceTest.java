package com.example.eduTech.services;

import com.example.eduTech.model.Curso;
import com.example.eduTech.repository.CursoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CursoServiceTest {

    @Mock
    private CursoRepository cursoRepository;

    @InjectMocks
    private CursoService cursoService;

    private Curso curso;

    @BeforeEach
    void setUp() {
        curso = new Curso(1, "Matemáticas", "Curso de matemáticas básicas", 40, null);
    }

    @Test
    void testGetAll_ShouldReturnListOfCursos() {
        when(cursoRepository.findAll()).thenReturn(Collections.singletonList(curso));

        List<Curso> cursos = cursoService.getAll();

        assertNotNull(cursos);
        assertEquals(1, cursos.size());
        assertEquals("Matemáticas", cursos.get(0).getNombre());
        verify(cursoRepository, times(1)).findAll();
    }

    @Test
    void testGetById_WhenCursoExists_ShouldReturnCurso() {
        when(cursoRepository.findById(1)).thenReturn(Optional.of(curso));

        Optional<Curso> resultado = cursoService.getById(1);

        assertTrue(resultado.isPresent());
        assertEquals(curso.getNombre(), resultado.get().getNombre());
        verify(cursoRepository, times(1)).findById(1);
    }

    @Test
    void testGetById_WhenCursoDoesNotExist_ShouldReturnEmpty() {
        when(cursoRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Curso> resultado = cursoService.getById(99);

        assertFalse(resultado.isPresent());
        verify(cursoRepository, times(1)).findById(99);
    }

    @Test
    void testCreate_ShouldReturnSavedCurso() {
        when(cursoRepository.save(any(Curso.class))).thenReturn(curso);

        Curso nuevoCurso = new Curso(1, "Matemáticas", "Curso de matemáticas básicas", 40, null);
        Curso cursoGuardado = cursoService.create(nuevoCurso);

        assertNotNull(cursoGuardado);
        assertEquals(1, cursoGuardado.getId_curso());
        verify(cursoRepository, times(1)).save(any(Curso.class));
    }

    @Test
    void testDelete_ShouldCallDeleteById() {
        int cursoId = 1;
        doNothing().when(cursoRepository).deleteById(cursoId);

        cursoService.delete(cursoId);

        verify(cursoRepository, times(1)).deleteById(cursoId);
    }
}