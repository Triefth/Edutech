package com.example.eduTech.controller;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.repository.AdministradorRepository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(AdminitradorController.class)

@AutoConfigureMockMvc(addFilters = false) // Desactiva filtros de seguridad para los tests
public class AdministradorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdministradorRepository administradorRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Administrador admin;

    @BeforeEach
    void setUp() {
        admin = new Administrador();
        admin.setId_administrador(1);
        admin.setNombre("Pedro");
        admin.setCorreo("pedro@mail.com");
        admin.setTelefono("123456789");
        admin.setUsuario("pedro123");
        admin.setContrasena("pass");
    }

    @Test
    public void testGetAllAdministradores() throws Exception {
        when(administradorRepository.findAll()).thenReturn(List.of(admin));

        mockMvc.perform(get("/administradores"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id_administrador").value(1))
            .andExpect(jsonPath("$[0].nombre").value("Pedro"));
    }

    @Test
    public void testGetAdministradorByIdFound() throws Exception {
        when(administradorRepository.findById(1)).thenReturn(Optional.of(admin));

        mockMvc.perform(get("/administradores/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Pedro"));
    }

    @Test
    public void testGetAdministradorByIdNotFound() throws Exception {
        when(administradorRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(get("/administradores/2"))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testCreateAdministrador() throws Exception {
        when(administradorRepository.save(any(Administrador.class))).thenReturn(admin);

        mockMvc.perform(post("/administradores")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(admin)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Pedro"));
    }

    @Test
    public void testUpdateAdministradorFound() throws Exception {
        Administrador updated = new Administrador();
        updated.setId_administrador(1);
        updated.setNombre("Pedro Actualizado");
        updated.setCorreo("pedro@mail.com");
        updated.setTelefono("123456789");
        updated.setUsuario("pedro123");
        updated.setContrasena("pass");

        when(administradorRepository.findById(1)).thenReturn(Optional.of(admin));
        when(administradorRepository.save(any(Administrador.class))).thenReturn(updated);

        mockMvc.perform(put("/administradores/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nombre").value("Pedro Actualizado"));
    }

    @Test
    public void testUpdateAdministradorNotFound() throws Exception {
        when(administradorRepository.findById(2)).thenReturn(Optional.empty());

        mockMvc.perform(put("/administradores/2")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(admin)))
            .andExpect(status().isOk())
            .andExpect(content().string(""));
    }

    @Test
    public void testDeleteAdministrador() throws Exception {
        doNothing().when(administradorRepository).deleteById(1);

        mockMvc.perform(delete("/administradores/1"))
            .andExpect(status().isOk());
    }
}