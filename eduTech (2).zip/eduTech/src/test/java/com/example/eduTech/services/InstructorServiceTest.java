package com.example.eduTech.services;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InstructorServiceTest {

    @Mock
    private InstructorRepository instructorRepository;

    @InjectMocks
    private InstructorService instructorService;

    private Instructor instructor;

    @BeforeEach
    void setUp() {
        instructor = new Instructor(1, "Luis", "luis@mail.com", "123456789", "luis123", "pass", null);
    }

    @Test
    void testGetAll_ShouldReturnListOfInstructores() {
        when(instructorRepository.findAll()).thenReturn(Collections.singletonList(instructor));
        List<Instructor> instructores = instructorService.getAll();
        assertNotNull(instructores);
        assertEquals(1, instructores.size());
        verify(instructorRepository, times(1)).findAll();
    }
    
    @Test
    void testCreate_WhenEmailAlreadyExists_ShouldThrowException() {
        // Arrange
        Instructor nuevoInstructor = new Instructor(1, "Luis", "luis@mail.com", "123456789", "luis123", "pass", null);
        when(instructorRepository.findByCorreo("luis@mail.com")).thenReturn(Optional.of(instructor));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            instructorService.create(nuevoInstructor);
        });

        assertEquals("El correo electrónico 'luis@mail.com' ya está en uso.", exception.getMessage());
        verify(instructorRepository, never()).save(any(Instructor.class));
    }

    @Test
    void testCreate_WhenUsuarioAlreadyExists_ShouldThrowException() {
        // Arrange
        Instructor nuevoInstructor = new Instructor(1, "Luis", "luis@mail.com", "123456789", "luis123", "pass", null);
        when(instructorRepository.findByUsuario("luis123")).thenReturn(Optional.of(instructor));

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            instructorService.create(nuevoInstructor);
        });

        assertEquals("El nombre de usuario 'luis123' ya está en uso.", exception.getMessage());
        verify(instructorRepository, never()).save(any(Instructor.class));
    }
}