package com.example.eduTech.controller;

import com.example.eduTech.model.Curso;
import com.example.eduTech.services.CursoService;
import com.example.eduTech.assemblers.CursoModelAssembler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/cursos")
@Tag(name = "Cursos V2", description = "Operaciones HATEOAS para cursos")
public class CursoControllerV2 {

    @Autowired
    private CursoService cursoService;

    @Autowired
    private CursoModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los cursos")
    public CollectionModel<EntityModel<Curso>> getAll() {
        List<EntityModel<Curso>> cursos = cursoService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(cursos, linkTo(methodOn(CursoControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un curso por ID")
    public EntityModel<Curso> getCursoById(@PathVariable Integer id) {
        Curso curso = cursoService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado con ID: " + id));
        return assembler.toModel(curso);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un curso")
    public ResponseEntity<EntityModel<Curso>> createCurso(@Valid @RequestBody Curso curso) {
        Curso nuevoCurso = cursoService.create(curso);
        EntityModel<Curso> entityModel = assembler.toModel(nuevoCurso);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un curso")
    public ResponseEntity<EntityModel<Curso>> updateCurso(@PathVariable Integer id, @Valid @RequestBody Curso cursoDetails) {
        Curso actualizado = cursoService.update(id, cursoDetails)
            .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Curso no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un curso")
    public ResponseEntity<?> deleteCurso(@PathVariable Integer id) {
        cursoService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Curso no encontrado con ID: " + id));
        cursoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    
}