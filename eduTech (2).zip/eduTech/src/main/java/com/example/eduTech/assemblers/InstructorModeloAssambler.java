package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.InstructorControllerV2;
import com.example.eduTech.model.Instructor;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class InstructorModeloAssambler implements RepresentationModelAssembler<Instructor, EntityModel<Instructor>> {

    @Override
    public EntityModel<Instructor> toModel(Instructor entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(InstructorControllerV2.class).getInstructorById(entity.getId_instructor())).withSelfRel(),
                linkTo(methodOn(InstructorControllerV2.class).getAll()).withRel("instructores"));
    }
}