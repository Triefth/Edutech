package com.example.eduTech.repository;

import com.example.eduTech.model.GerenteDeCursos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface GerenteDeCursoRepository extends JpaRepository<GerenteDeCursos, Integer> {

    /**
     * Busca un gerente de cursos por su dirección de correo electrónico.
     * @param correo El correo a buscar.
     * @return un Optional que contiene al gerente si se encuentra, o vacío si no.
     */
    Optional<GerenteDeCursos> findByCorreo(String correo);

    /**
     * Busca un gerente de cursos por su nombre de usuario.
     * @param usuario El nombre de usuario a buscar.
     * @return un Optional que contiene al gerente si se encuentra, o vacío si no.
     */
    Optional<GerenteDeCursos> findByUsuario(String usuario);
}