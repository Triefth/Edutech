package com.example.eduTech.controller;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.services.LogisticaSoporteService; // Usamos el Servicio
import com.example.eduTech.assemblers.LogicaSoporteModeloAssambler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Importamos Valid
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/logistica-soporte")
@Tag(name = "Logística Soporte V2", description = "Operaciones HATEOAS para logística y soporte")
public class LogicaSoporteControllerV2 {

    @Autowired
    private LogisticaSoporteService logisticaSoporteService; // Inyectamos el Servicio

    @Autowired
    private LogicaSoporteModeloAssambler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los registros de logística y soporte")
    public CollectionModel<EntityModel<LogisticaSoporte>> getAll() {
        List<EntityModel<LogisticaSoporte>> lista = logisticaSoporteService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(lista, linkTo(methodOn(LogicaSoporteControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un registro de logística/soporte por ID")
    public EntityModel<LogisticaSoporte> getLogisticaSoporteById(@PathVariable Integer id) {
        LogisticaSoporte logistica = logisticaSoporteService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Registro de Logística/Soporte no encontrado con ID: " + id));
        return assembler.toModel(logistica);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un registro de logística/soporte")
    public ResponseEntity<EntityModel<LogisticaSoporte>> createLogisticaSoporte(@Valid @RequestBody LogisticaSoporte logisticaSoporte) {
        LogisticaSoporte nuevo = logisticaSoporteService.create(logisticaSoporte);
        EntityModel<LogisticaSoporte> entityModel = assembler.toModel(nuevo);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un registro de logística/soporte")
    public ResponseEntity<EntityModel<LogisticaSoporte>> updateLogisticaSoporte(@PathVariable Integer id, @Valid @RequestBody LogisticaSoporte details) {
        LogisticaSoporte actualizado = logisticaSoporteService.update(id, details)
            .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Registro no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un registro de logística/soporte")
    public ResponseEntity<?> deleteLogisticaSoporte(@PathVariable Integer id) {
        logisticaSoporteService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Registro no encontrado con ID: " + id));
        logisticaSoporteService.delete(id);
        return ResponseEntity.noContent().build();
    }
}