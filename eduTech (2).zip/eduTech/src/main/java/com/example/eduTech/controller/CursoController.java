package com.example.eduTech.controller;

import com.example.eduTech.model.Curso;
import com.example.eduTech.repository.CursoRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/cursos")
@Tag(name = "Cursos", description = "Operaciones relacionadas con cursos")
public class CursoController {

    @Autowired
    private CursoRepository cursoRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los cursos",
        description = "Obtiene una lista de todos los cursos disponibles en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = Curso.class)),
                examples = @ExampleObject(
                    name = "EjemploListaCursos",
                    value = "[{\"id_curso\":1,\"nombre\":\"Matemáticas\",\"descripcion\":\"Curso de matemáticas básicas\",\"duracion\":40}]"
                )
            )
        )
    })
    public List<Curso> getAll() {
        return cursoRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un curso",
        description = "Crea un nuevo curso en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Curso creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Curso.class),
                examples = @ExampleObject(
                    name = "EjemploCurso",
                    value = "{\"id_curso\":2,\"nombre\":\"Lenguaje\",\"descripcion\":\"Curso de lenguaje avanzado\",\"duracion\":30}"
                )
            )
        )
    })
    public Curso create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Curso a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = Curso.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Lenguaje\",\"descripcion\":\"Curso de lenguaje avanzado\",\"duracion\":30}"
                )
            )
        )
        @Valid @RequestBody Curso curso // <-- aquí se agrega @Valid
    ) {
        return cursoRepository.save(curso);
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un curso por ID",
        description = "Obtiene un curso específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Curso encontrado",
            content = @Content(schema = @Schema(implementation = Curso.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Curso no encontrado\"}"
                )
            )
        )
    })
    public Curso getById(
        @Parameter(description = "ID del curso", required = true)
        @PathVariable Integer id
    ) {
        return cursoRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un curso",
        description = "Actualiza los datos de un curso existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Curso actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Curso.class),
                examples = @ExampleObject(
                    name = "EjemploCursoActualizado",
                    value = "{\"id_curso\":1,\"nombre\":\"Matemáticas Avanzadas\",\"descripcion\":\"Curso de matemáticas avanzadas\",\"duracion\":60}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Curso no encontrado\"}"
                )
            )
        )
    })
    public Curso update(
        @Parameter(description = "ID del curso", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody Curso cursoDetails // <-- aquí se agrega @Valid
    ) {
        return cursoRepository.findById(id).map(curso -> {
            curso.setNombre(cursoDetails.getNombre());
            curso.setDescripcion(cursoDetails.getDescripcion());
            curso.setDuracion(cursoDetails.getDuracion());
            return cursoRepository.save(curso);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un curso",
        description = "Elimina un curso por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Curso eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Curso no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del curso", required = true)
        @PathVariable Integer id
    ) {
        cursoRepository.deleteById(id);
    }
}