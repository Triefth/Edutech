package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.CursoControllerV2;
import com.example.eduTech.model.Curso;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CursoModelAssembler implements RepresentationModelAssembler<Curso, EntityModel<Curso>> {

    @Override
    public EntityModel<Curso> toModel(Curso entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(CursoControllerV2.class).getCursoById(entity.getId_curso())).withSelfRel(),
                linkTo(methodOn(CursoControllerV2.class).getAll()).withRel("cursos"));
    }
}