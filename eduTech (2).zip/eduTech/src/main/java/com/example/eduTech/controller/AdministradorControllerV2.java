package com.example.eduTech.controller;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.services.AdministradorService; // Usamos el Servicio
import com.example.eduTech.assemblers.AdministradorModelAssembler;
import com.example.eduTech.exception.ResourceNotFoundException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Importamos Valid
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/administradores")
@Tag(name = "Administradores V2", description = "Operaciones HATEOAS para administradores")
public class AdministradorControllerV2 {

    @Autowired
    private AdministradorService administradorService; // Inyectamos el Servicio

    @Autowired
    private AdministradorModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener todos los administradores")
    public CollectionModel<EntityModel<Administrador>> getAll() {
        List<EntityModel<Administrador>> administradores = administradorService.getAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());
        return CollectionModel.of(administradores, linkTo(methodOn(AdministradorControllerV2.class).getAll()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Obtener un administrador por ID")
    public EntityModel<Administrador> getAdministradorById(@PathVariable Integer id) {
        Administrador admin = administradorService.getById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Administrador no encontrado con ID: " + id));
        return assembler.toModel(admin);
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Crear un administrador")
    public ResponseEntity<EntityModel<Administrador>> createAdministrador(@Valid @RequestBody Administrador administrador) {
        Administrador nuevoAdmin = administradorService.create(administrador); // Lógica de negocio en el servicio
        EntityModel<Administrador> entityModel = assembler.toModel(nuevoAdmin);
        return ResponseEntity.created(entityModel.getRequiredLink("self").toUri()).body(entityModel);
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    @Operation(summary = "Actualizar un administrador")
    public ResponseEntity<EntityModel<Administrador>> updateAdministrador(@PathVariable Integer id, @Valid @RequestBody Administrador administradorDetails) {
        Administrador actualizado = administradorService.update(id, administradorDetails)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar. Administrador no encontrado con ID: " + id));
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}")
    @Operation(summary = "Eliminar un administrador")
    public ResponseEntity<?> deleteAdministrador(@PathVariable Integer id) {
        // Verificamos si existe antes de borrar para poder lanzar nuestro 404
        administradorService.getById(id).orElseThrow(() -> new ResourceNotFoundException("No se puede eliminar. Administrador no encontrado con ID: " + id));
        administradorService.delete(id);
        return ResponseEntity.noContent().build();
    }
}