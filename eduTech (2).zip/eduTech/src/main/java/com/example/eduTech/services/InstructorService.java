package com.example.eduTech.services;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InstructorService {

    @Autowired
    private InstructorRepository instructorRepository;

    public List<Instructor> getAll() {
        return instructorRepository.findAll();
    }

    public Optional<Instructor> getById(Integer id) {
        return instructorRepository.findById(id);
    }

    public Instructor create(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    public Optional<Instructor> update(Integer id, Instructor instructorDetails) {
        return instructorRepository.findById(id).map(instructor -> {
            instructor.setNombre(instructorDetails.getNombre());
            instructor.setCorreo(instructorDetails.getCorreo());
            instructor.setTelefono(instructorDetails.getTelefono());
            instructor.setUsuario(instructorDetails.getUsuario());
            instructor.setContrasena(instructorDetails.getContrasena());
            return instructorRepository.save(instructor);
        });
    }

    public void delete(Integer id) {
        instructorRepository.deleteById(id);
    }
}