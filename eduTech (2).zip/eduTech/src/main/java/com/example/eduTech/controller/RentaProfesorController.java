package com.example.eduTech.controller;

import com.example.eduTech.model.RentaProfesor;
import com.example.eduTech.services.RentaProfesorCarritoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1/renta-profesor")
@Tag(name = "Carrito de Rentas (V1)", description = "Operaciones de carrito en memoria para la renta de profesores")
public class RentaProfesorController {

    @Autowired
    private RentaProfesorCarritoService rentaProfesorCarritoService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Agregar una Renta al Carrito", description = "Agrega un objeto de renta a la lista temporal del carrito.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Renta agregada al carrito exitosamente", content = @Content(schema = @Schema(implementation = RentaProfesor.class))),
        @ApiResponse(responseCode = "400", description = "Datos de la renta inválidos")
    })
    public RentaProfesor agregarAlCarrito(@Valid @RequestBody RentaProfesor renta) {
        rentaProfesorCarritoService.agregarRenta(renta);
        return renta; // Devolvemos el objeto agregado como confirmación
    }

    @GetMapping
    @Operation(summary = "Ver Contenido del Carrito", description = "Obtiene la lista de todas las rentas actualmente en el carrito.")
    @ApiResponse(responseCode = "200", description = "Carrito obtenido exitosamente", content = @Content(array = @ArraySchema(schema = @Schema(implementation = RentaProfesor.class))))
    public List<RentaProfesor> verCarrito() {
        return rentaProfesorCarritoService.verCarrito();
    }

    @DeleteMapping("/eliminar/{index}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Eliminar una Renta del Carrito por Índice", description = "Elimina una renta específica del carrito usando su posición en la lista (iniciando en 0).")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Renta eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "No se encontró una renta en el índice especificado")
    })
    public void eliminarDelCarrito(@Parameter(description = "Índice del elemento a eliminar", required = true) @PathVariable int index) {
        String resultado = rentaProfesorCarritoService.eliminarRenta(index);
        if (resultado.contains("No se encontró")) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, resultado);
        }
    }

    @DeleteMapping("/vaciar")
    @Operation(summary = "Vaciar todo el Carrito", description = "Elimina todos los elementos del carrito de rentas.")
    @ApiResponse(responseCode = "200", description = "Carrito vaciado")
    public String vaciarCarrito() {
        return rentaProfesorCarritoService.vaciarCarrito();
    }

    @PostMapping("/comprar")
    @Operation(summary = "Simular Compra", description = "Confirma las rentas del carrito y lo vacía.")
    @ApiResponse(responseCode = "200", description = "Compra simulada exitosamente")
    public String comprar() {
        return rentaProfesorCarritoService.comprar();
    }

    @GetMapping("/total")
    @Operation(summary = "Obtener Total de Ítems en Carrito", description = "Devuelve la cantidad de rentas que hay en el carrito.")
    @ApiResponse(responseCode = "200", description = "Total obtenido")
    public int totalRentasCarrito() {
        return rentaProfesorCarritoService.totalRentasCarrito();
    }
}