package com.example.eduTech.assemblers;

import com.example.eduTech.controller.RentaProfesorControllerV2;
import com.example.eduTech.model.RentaProfesor;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class RentaProfesorModeloAssambler implements RepresentationModelAssembler<RentaProfesor, EntityModel<RentaProfesor>> {

    @Override
    public EntityModel<RentaProfesor> toModel(RentaProfesor entity) {
        EntityModel<RentaProfesor> rentaModel = EntityModel.of(entity);

        // Construimos los enlaces de una forma más explícita y segura
        // que es menos propensa a causar problemas de recursión.
        rentaModel.add(WebMvcLinkBuilder.linkTo(
                WebMvcLinkBuilder.methodOn(RentaProfesorControllerV2.class)
                .getRentaProfesorById(entity.getId_renta()))
                .withSelfRel());
        
        rentaModel.add(WebMvcLinkBuilder.linkTo(
                WebMvcLinkBuilder.methodOn(RentaProfesorControllerV2.class)
                .getAll())
                .withRel("rentas-profesor"));

        return rentaModel;
    }
}