package com.example.eduTech.controller;

import com.example.eduTech.model.Instructor;
import com.example.eduTech.repository.InstructorRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/instructores")
@Tag(name = "Instructores", description = "Operaciones relacionadas con instructores")
public class InstructorController {

    @Autowired
    private InstructorRepository instructorRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los instructores",
        description = "Obtiene una lista de todos los instructores disponibles en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = Instructor.class)),
                examples = @ExampleObject(
                    name = "EjemploListaInstructores",
                    value = "[{\"id_instructor\":1,\"nombre\":\"Luis\",\"correo\":\"luis@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"luis123\",\"contrasena\":\"pass\"}]"
                )
            )
        )
    })
    public List<Instructor> getAll() {
        return instructorRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un instructor",
        description = "Crea un nuevo instructor en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Instructor creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Instructor.class),
                examples = @ExampleObject(
                    name = "EjemploInstructor",
                    value = "{\"id_instructor\":2,\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
    })
    public Instructor create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Instructor a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = Instructor.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
        @Valid @RequestBody Instructor instructor // <-- aquí se agrega @Valid
    ) {
        return instructorRepository.save(instructor);
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un instructor por ID",
        description = "Obtiene un instructor específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Instructor encontrado",
            content = @Content(schema = @Schema(implementation = Instructor.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Instructor no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Instructor no encontrado\"}"
                )
            )
        )
    })
    public Instructor getById(
        @Parameter(description = "ID del instructor", required = true)
        @PathVariable Integer id
    ) {
        return instructorRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un instructor",
        description = "Actualiza los datos de un instructor existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Instructor actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Instructor.class),
                examples = @ExampleObject(
                    name = "EjemploInstructorActualizado",
                    value = "{\"id_instructor\":1,\"nombre\":\"Luis Actualizado\",\"correo\":\"luis@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"luis123\",\"contrasena\":\"pass\"}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Instructor no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Instructor no encontrado\"}"
                )
            )
        )
    })
    public Instructor update(
        @Parameter(description = "ID del instructor", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody Instructor instructorDetails // <-- aquí se agrega @Valid
    ) {
        return instructorRepository.findById(id).map(instructor -> {
            instructor.setNombre(instructorDetails.getNombre());
            instructor.setCorreo(instructorDetails.getCorreo());
            instructor.setTelefono(instructorDetails.getTelefono());
            instructor.setUsuario(instructorDetails.getUsuario());
            instructor.setContrasena(instructorDetails.getContrasena());
            return instructorRepository.save(instructor);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un instructor",
        description = "Elimina un instructor por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Instructor eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Instructor no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Instructor no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del instructor", required = true)
        @PathVariable Integer id
    ) {
        instructorRepository.deleteById(id);
    }
}