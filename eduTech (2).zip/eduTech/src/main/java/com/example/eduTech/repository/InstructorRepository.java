package com.example.eduTech.repository;

import com.example.eduTech.model.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Integer> {

    /**
     * Busca un instructor por su dirección de correo electrónico.
     * @param correo El correo a buscar.
     * @return un Optional que contiene al instructor si se encuentra, o vacío si no.
     */
    Optional<Instructor> findByCorreo(String correo);

    /**
     * Busca un instructor por su nombre de usuario.
     * @param usuario El nombre de usuario a buscar.
     * @return un Optional que contiene al instructor si se encuentra, o vacío si no.
     */
    Optional<Instructor> findByUsuario(String usuario);
}