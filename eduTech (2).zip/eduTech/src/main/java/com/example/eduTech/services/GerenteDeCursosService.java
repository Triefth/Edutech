package com.example.eduTech.services;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GerenteDeCursosService {

    @Autowired
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    public List<GerenteDeCursos> getAll() {
        return gerenteDeCursoRepository.findAll();
    }

    public Optional<GerenteDeCursos> getById(Integer id) {
        return gerenteDeCursoRepository.findById(id);
    }

    public GerenteDeCursos create(GerenteDeCursos gerente) {
        return gerenteDeCursoRepository.save(gerente);
    }

    public Optional<GerenteDeCursos> update(Integer id, GerenteDeCursos gerenteDetails) {
        return gerenteDeCursoRepository.findById(id).map(gerente -> {
            gerente.setNombre(gerenteDetails.getNombre());
            gerente.setCorreo(gerenteDetails.getCorreo());
            gerente.setTelefono(gerenteDetails.getTelefono());
            gerente.setUsuario(gerenteDetails.getUsuario());
            gerente.setContrasena(gerenteDetails.getContrasena());
            return gerenteDeCursoRepository.save(gerente);
        });
    }

    public void delete(Integer id) {
        gerenteDeCursoRepository.deleteById(id);
    }
}