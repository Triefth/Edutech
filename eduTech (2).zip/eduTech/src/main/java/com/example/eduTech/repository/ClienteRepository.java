package com.example.eduTech.repository;

import com.example.eduTech.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    /**
     * Busca un cliente por su dirección de correo electrónico.
     * Útil para validar que no se registren clientes con el mismo email.
     * @param correo El correo a buscar.
     * @return un Optional que contiene al cliente si se encuentra, o vacío si no.
     */
    Optional<Cliente> findByCorreo(String correo);
}