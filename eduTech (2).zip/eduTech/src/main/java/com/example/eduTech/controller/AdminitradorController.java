package com.example.eduTech.controller;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.repository.AdministradorRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/administradores")
@Tag(name = "Administradores", description = "Operaciones relacionadas con administradores")
public class AdminitradorController {

    @Autowired
    private AdministradorRepository administradorRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los administradores",
        description = "Obtiene una lista de todos los administradores disponibles en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = Administrador.class)),
                examples = @ExampleObject(
                    name = "EjemploListaAdministradores",
                    value = "[{\"id_administrador\":1,\"nombre\":\"Pedro\",\"correo\":\"pedro@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"pedro123\",\"contrasena\":\"pass\"}]"
                )
            )
        )
    })
    public List<Administrador> getAll() {
        return administradorRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un administrador",
        description = "Crea un nuevo administrador en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Administrador creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Administrador.class),
                examples = @ExampleObject(
                    name = "EjemploAdministrador",
                    value = "{\"id_administrador\":2,\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
    })
    public Administrador create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Administrador a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = Administrador.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
        @Valid @RequestBody Administrador administrador
    ) {
        return administradorRepository.save(administrador);
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un administrador por ID",
        description = "Obtiene un administrador específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Administrador encontrado",
            content = @Content(schema = @Schema(implementation = Administrador.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Administrador no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Administrador no encontrado\"}"
                )
            )
        )
    })
    public Administrador getById(
        @Parameter(description = "ID del administrador", required = true)
        @PathVariable Integer id
    ) {
        return administradorRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un administrador",
        description = "Actualiza los datos de un administrador existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Administrador actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = Administrador.class),
                examples = @ExampleObject(
                    name = "EjemploAdministradorActualizado",
                    value = "{\"id_administrador\":1,\"nombre\":\"Pedro Actualizado\",\"correo\":\"pedro@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"pedro123\",\"contrasena\":\"pass\"}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Administrador no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Administrador no encontrado\"}"
                )
            )
        )
    })
    public Administrador update(
        @Parameter(description = "ID del administrador", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody Administrador administradorDetails
    ) {
        return administradorRepository.findById(id).map(administrador -> {
            administrador.setNombre(administradorDetails.getNombre());
            administrador.setCorreo(administradorDetails.getCorreo());
            administrador.setTelefono(administradorDetails.getTelefono());
            administrador.setUsuario(administradorDetails.getUsuario());
            administrador.setContrasena(administradorDetails.getContrasena());
            return administradorRepository.save(administrador);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un administrador",
        description = "Elimina un administrador por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Administrador eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Administrador no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Administrador no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del administrador", required = true)
        @PathVariable Integer id
    ) {
        administradorRepository.deleteById(id);
    }
}