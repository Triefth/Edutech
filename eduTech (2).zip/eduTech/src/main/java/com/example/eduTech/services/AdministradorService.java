package com.example.eduTech.services;

import com.example.eduTech.model.Administrador;
import com.example.eduTech.repository.AdministradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministradorService {

    @Autowired
    private AdministradorRepository administradorRepository;

    public List<Administrador> getAll() {
        return administradorRepository.findAll();
    }

    public Optional<Administrador> getById(Integer id) {
        return administradorRepository.findById(id);
    }

    public Administrador create(Administrador administrador) {
        return administradorRepository.save(administrador);
    }

    public Optional<Administrador> update(Integer id, Administrador administradorDetails) {
        return administradorRepository.findById(id).map(administrador -> {
            administrador.setNombre(administradorDetails.getNombre());
            administrador.setCorreo(administradorDetails.getCorreo());
            administrador.setTelefono(administradorDetails.getTelefono());
            administrador.setUsuario(administradorDetails.getUsuario());
            administrador.setContrasena(administradorDetails.getContrasena());
            return administradorRepository.save(administrador);
        });
    }

    public void delete(Integer id) {
        administradorRepository.deleteById(id);
    }
}