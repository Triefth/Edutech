package com.example.eduTech.services;

import com.example.eduTech.model.RentaProfesor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service // Puedes llamarlo "rentaProfesorCarritoService" para ser específico
public class RentaProfesorCarritoService {

    private final List<RentaProfesor> carrito = new ArrayList<>();

    public String agregarRenta(RentaProfesor renta) {
        carrito.add(renta);
        return "Curso agregado al carrito de renta de profesor";
    }

    public String eliminarRenta(int index) {
        if (index >= 0 && index < carrito.size()) {
            carrito.remove(index);
            return "Renta eliminada del carrito";
        }
        return "No se encontró la renta en el carrito";
    }

    public List<RentaProfesor> verCarrito() {
        return carrito;
    }

    public String vaciarCarrito() {
        carrito.clear();
        return "El carrito de renta de profesor está vacío";
    }

    public String comprar() {
        carrito.clear();
        return "Renta(s) realizada(s) con éxito";
    }

    public int totalRentasCarrito() {
        return carrito.size();
    }
}