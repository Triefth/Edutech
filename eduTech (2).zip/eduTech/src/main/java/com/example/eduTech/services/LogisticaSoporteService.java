package com.example.eduTech.services;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LogisticaSoporteService {

    @Autowired
    private LogisticaSoporteRepository logisticaSoporteRepository;

    public List<LogisticaSoporte> getAll() {
        return logisticaSoporteRepository.findAll();
    }

    public Optional<LogisticaSoporte> getById(Integer id) {
        return logisticaSoporteRepository.findById(id);
    }

    public LogisticaSoporte create(LogisticaSoporte logisticaSoporte) {
        return logisticaSoporteRepository.save(logisticaSoporte);
    }

    public Optional<LogisticaSoporte> update(Integer id, LogisticaSoporte details) {
        return logisticaSoporteRepository.findById(id).map(logisticaSoporte -> {
            logisticaSoporte.setNombre(details.getNombre());
            logisticaSoporte.setCorreo(details.getCorreo());
            logisticaSoporte.setTelefono(details.getTelefono());
            logisticaSoporte.setUsuario(details.getUsuario());
            logisticaSoporte.setContrasena(details.getContrasena());
            return logisticaSoporteRepository.save(logisticaSoporte);
        });
    }

    public void delete(Integer id) {
        logisticaSoporteRepository.deleteById(id);
    }
}