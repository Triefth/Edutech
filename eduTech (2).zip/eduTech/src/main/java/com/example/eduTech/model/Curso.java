package com.example.eduTech.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Table(name = "cursos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_curso;

    @NotBlank(message = "El nombre del curso no puede estar vacío.")
    @Size(min = 3, max = 150, message = "El nombre del curso debe tener entre 3 y 150 caracteres.")
    private String nombre;

    @Size(max = 500, message = "La descripción no puede superar los 500 caracteres.")
    private String descripcion;

    @NotNull(message = "La duración es obligatoria.")
    @Min(value = 1, message = "La duración del curso debe ser de al menos 1 hora.")
    
    private Integer duracion;
    @ManyToMany(mappedBy = "cursos", fetch = FetchType.LAZY)
    @JsonIgnore 
    private List<RentaProfesor> rentas;
}