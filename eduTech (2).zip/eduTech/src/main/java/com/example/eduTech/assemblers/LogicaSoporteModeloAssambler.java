package com.example.eduTech.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.eduTech.controller.LogicaSoporteControllerV2;
import com.example.eduTech.model.LogisticaSoporte;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class LogicaSoporteModeloAssambler implements RepresentationModelAssembler<LogisticaSoporte, EntityModel<LogisticaSoporte>> {

    @Override
    public EntityModel<LogisticaSoporte> toModel(LogisticaSoporte entity) {
        return EntityModel.of(entity,
                linkTo(methodOn(LogicaSoporteControllerV2.class).getLogisticaSoporteById(entity.getId_logistica_soporte())).withSelfRel(),
                linkTo(methodOn(LogicaSoporteControllerV2.class).getAll()).withRel("logisticaSoporte"));
    }
}