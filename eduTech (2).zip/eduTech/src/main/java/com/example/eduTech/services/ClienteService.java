package com.example.eduTech.services;

import com.example.eduTech.model.Cliente;
import com.example.eduTech.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> getAll() {
        return clienteRepository.findAll();
    }

    public Optional<Cliente> getById(Integer id) {
        return clienteRepository.findById(id);
    }

    // --- MÉTODO ACTUALIZADO CON LA REGLA DE NEGOCIO ---
    public Cliente create(Cliente cliente) {
        // Regla: El correo electrónico del cliente no debe estar ya en uso.
        if (clienteRepository.findByCorreo(cliente.getCorreo()).isPresent()) {
            throw new IllegalArgumentException("El correo electrónico '" + cliente.getCorreo() + "' ya está en uso.");
        }
        return clienteRepository.save(cliente);
    }

    public Optional<Cliente> update(Integer id, Cliente clienteDetails) {
        return clienteRepository.findById(id).map(cliente -> {
            // Opcional: Podrías añadir una validación aquí también si el correo cambia
            // y es diferente al del cliente actual pero igual a otro.
            cliente.setNombre(clienteDetails.getNombre());
            cliente.setTelefono(clienteDetails.getTelefono());
            cliente.setCorreo(clienteDetails.getCorreo());
            cliente.setDireccion(clienteDetails.getDireccion());
            return clienteRepository.save(cliente);
        });
    }

    public void delete(Integer id) {
        clienteRepository.deleteById(id);
    }
}