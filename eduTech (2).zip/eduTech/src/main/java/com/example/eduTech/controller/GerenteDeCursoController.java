package com.example.eduTech.controller;

import com.example.eduTech.model.GerenteDeCursos;
import com.example.eduTech.repository.GerenteDeCursoRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/gerentes-de-cursos")
@Tag(name = "Gerentes de Cursos", description = "Operaciones relacionadas con gerentes de cursos")
public class GerenteDeCursoController {

    @Autowired
    private GerenteDeCursoRepository gerenteDeCursoRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los gerentes de cursos",
        description = "Obtiene una lista de todos los gerentes de cursos disponibles en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = GerenteDeCursos.class)),
                examples = @ExampleObject(
                    name = "EjemploListaGerentes",
                    value = "[{\"id_gerente\":1,\"nombre\":\"Laura\",\"correo\":\"laura@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"laura123\",\"contrasena\":\"pass\"}]"
                )
            )
        )
    })
    public List<GerenteDeCursos> getAll() {
        return gerenteDeCursoRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un gerente de curso",
        description = "Crea un nuevo gerente de curso en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Gerente de curso creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = GerenteDeCursos.class),
                examples = @ExampleObject(
                    name = "EjemploGerente",
                    value = "{\"id_gerente\":2,\"nombre\":\"Mario\",\"correo\":\"mario@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"mario456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
    })
    public GerenteDeCursos create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Gerente de curso a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = GerenteDeCursos.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Mario\",\"correo\":\"mario@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"mario456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
        @Valid @RequestBody GerenteDeCursos gerente // <-- aquí se agrega @Valid
    ) {
        return gerenteDeCursoRepository.save(gerente);
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un gerente de curso por ID",
        description = "Obtiene un gerente de curso específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Gerente de curso encontrado",
            content = @Content(schema = @Schema(implementation = GerenteDeCursos.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Gerente de curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Gerente de curso no encontrado\"}"
                )
            )
        )
    })
    public GerenteDeCursos getById(
        @Parameter(description = "ID del gerente de curso", required = true)
        @PathVariable Integer id
    ) {
        return gerenteDeCursoRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un gerente de curso",
        description = "Actualiza los datos de un gerente de curso existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Gerente de curso actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = GerenteDeCursos.class),
                examples = @ExampleObject(
                    name = "EjemploGerenteActualizado",
                    value = "{\"id_gerente\":1,\"nombre\":\"Laura Actualizada\",\"correo\":\"laura@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"laura123\",\"contrasena\":\"pass\"}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Gerente de curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Gerente de curso no encontrado\"}"
                )
            )
        )
    })
    public GerenteDeCursos update(
        @Parameter(description = "ID del gerente de curso", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody GerenteDeCursos gerenteDetails // <-- aquí se agrega @Valid
    ) {
        return gerenteDeCursoRepository.findById(id).map(gerente -> {
            gerente.setNombre(gerenteDetails.getNombre());
            gerente.setCorreo(gerenteDetails.getCorreo());
            gerente.setTelefono(gerenteDetails.getTelefono());
            gerente.setUsuario(gerenteDetails.getUsuario());
            gerente.setContrasena(gerenteDetails.getContrasena());
            return gerenteDeCursoRepository.save(gerente);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un gerente de curso",
        description = "Elimina un gerente de curso por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Gerente de curso eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Gerente de curso no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Gerente de curso no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del gerente de curso", required = true)
        @PathVariable Integer id
    ) {
        gerenteDeCursoRepository.deleteById(id);
    }
}