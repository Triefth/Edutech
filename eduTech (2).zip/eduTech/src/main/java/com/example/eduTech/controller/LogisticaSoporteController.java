package com.example.eduTech.controller;

import com.example.eduTech.model.LogisticaSoporte;
import com.example.eduTech.repository.LogisticaSoporteRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/logistica-soporte")
@Tag(name = "Logística y Soporte", description = "Operaciones relacionadas con logística y soporte")
public class LogisticaSoporteController {

    @Autowired
    private LogisticaSoporteRepository logisticaSoporteRepository;

    @GetMapping
    @Operation(
        summary = "Obtener todos los registros de logística y soporte",
        description = "Obtiene una lista de todos los registros de logística y soporte disponibles en el sistema"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Operación exitosa",
            content = @Content(
                mediaType = "application/json",
                array = @ArraySchema(schema = @Schema(implementation = LogisticaSoporte.class)),
                examples = @ExampleObject(
                    name = "EjemploListaLogisticaSoporte",
                    value = "[{\"id_logistica_soporte\":1,\"nombre\":\"Juan\",\"correo\":\"juan@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"juan123\",\"contrasena\":\"pass\"}]"
                )
            )
        )
    })
    public List<LogisticaSoporte> getAll() {
        return logisticaSoporteRepository.findAll();
    }

    @PostMapping
    @Operation(
        summary = "Crear un registro de logística y soporte",
        description = "Crea un nuevo registro de logística y soporte en el sistema."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Registro creado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = LogisticaSoporte.class),
                examples = @ExampleObject(
                    name = "EjemploLogisticaSoporte",
                    value = "{\"id_logistica_soporte\":2,\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
    })
    public LogisticaSoporte create(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Registro de logística y soporte a crear",
            required = true,
            content = @Content(
                schema = @Schema(implementation = LogisticaSoporte.class),
                examples = @ExampleObject(
                    value = "{\"nombre\":\"Ana\",\"correo\":\"ana@mail.com\",\"telefono\":\"987654321\",\"usuario\":\"ana456\",\"contrasena\":\"pass2\"}"
                )
            )
        )
        @Valid @RequestBody LogisticaSoporte logisticaSoporte // <-- aquí se agrega @Valid
    ) {
        return logisticaSoporteRepository.save(logisticaSoporte);
    }


    @GetMapping("/{id}")
    @Operation(
        summary = "Obtener un registro de logística y soporte por ID",
        description = "Obtiene un registro de logística y soporte específico usando su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Registro encontrado",
            content = @Content(schema = @Schema(implementation = LogisticaSoporte.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Registro no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Registro no encontrado\"}"
                )
            )
        )
    })
    public LogisticaSoporte getById(
        @Parameter(description = "ID del registro de logística y soporte", required = true)
        @PathVariable Integer id
    ) {
        return logisticaSoporteRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Actualizar un registro de logística y soporte",
        description = "Actualiza los datos de un registro de logística y soporte existente."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Registro actualizado exitosamente",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = LogisticaSoporte.class),
                examples = @ExampleObject(
                    name = "EjemploLogisticaSoporteActualizada",
                    value = "{\"id_logistica_soporte\":1,\"nombre\":\"Juan Actualizado\",\"correo\":\"juan@mail.com\",\"telefono\":\"123456789\",\"usuario\":\"juan123\",\"contrasena\":\"pass\"}"
                )
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Registro no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Registro no encontrado\"}"
                )
            )
        )
    })
    public LogisticaSoporte update(
        @Parameter(description = "ID del registro de logística y soporte", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody LogisticaSoporte logisticaSoporteDetails // <-- aquí se agrega @Valid
    ) {
        return logisticaSoporteRepository.findById(id).map(logisticaSoporte -> {
            logisticaSoporte.setNombre(logisticaSoporteDetails.getNombre());
            logisticaSoporte.setCorreo(logisticaSoporteDetails.getCorreo());
            logisticaSoporte.setTelefono(logisticaSoporteDetails.getTelefono());
            logisticaSoporte.setUsuario(logisticaSoporteDetails.getUsuario());
            logisticaSoporte.setContrasena(logisticaSoporteDetails.getContrasena());
            return logisticaSoporteRepository.save(logisticaSoporte);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    @Operation(
        summary = "Eliminar un registro de logística y soporte",
        description = "Elimina un registro de logística y soporte por su ID."
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Registro eliminado exitosamente"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Registro no encontrado",
            content = @Content(
                mediaType = "application/json",
                examples = @ExampleObject(
                    value = "{\"mensaje\": \"Registro no encontrado\"}"
                )
            )
        )
    })
    public void delete(
        @Parameter(description = "ID del registro de logística y soporte", required = true)
        @PathVariable Integer id
    ) {
        logisticaSoporteRepository.deleteById(id);
    }
}